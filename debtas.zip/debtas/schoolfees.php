<?php include("includes/header.php"); ?>
  <main>
      <?php include("fees.php"); ?> 
  </main>
<?php include("includes/footer.php"); ?>