<div class="container-fluid col-12" id="banContainerFluid" >
    <div class="container col-12 d-none d-md-block" id="banContainer">
            <div class="banner col-12">
                <img src="images/stu7.png" />
            </div>
    </div>
    <div class="container col-12" id="whoContainer">
            <div class="row col-12">
                <h3> ABOUT US :: Who we are</h3>
                <div id="articleDiv" class="col-12">
                    
                    <div class="col-xl-4 col-lg-4 col-md-4 col-sm-4 col-xs-12 d-none d-md-block " id="artImg">
                      <img src="images/logo.png" alt="articleimage">
                    </div>

                    <div id="artText" class="col-xl-8 col-lg-8 col-md-8 col-sm-12 col-xs-12">
                      
                      <p>
                      DE-BRAIN-TUTOR ADVANCED STUDIES EDUCATIONAL SERVICES is an advanced institute of education with the aim of setting goals for students who are seeking admission into Nigeria University of their choice. Our organization is also with the mission of giving students the basis to nurture their future and academics, this organusation is with a mission of providing strategies of implementation and providing absolute solutions to all educational and academic challenges.

                      DE-BRAIN-TUTOR ADVANCED STUDIES EDUCATIONAL SERVICES is established out of rigorous experiences of the academics issues and the available solutions to the recurrent chanllenges that the students are facing outside and within the University environment.

                      Our organization competence and credibility could be remarkably traced to the initiation of the A'level Programs that is associated to the securing of admissions with or without Unified Tertiary Matriculation Examination (UTME) and our result of achievement so far could be traced to wide range of student that our organization have been able to give support in succuring admission into different Universities across the nation.
                      </p>

                    </div>

                </div>
            </div>

    </div>

</div>