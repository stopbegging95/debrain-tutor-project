<!-- Note: the examination offers hmtl code start here here  -->

<div class="container-fluid" id="examOffers">
        <div class="container col-12"> 
            
               <div id="offerHeading" class="col-12">
                 <h3>  Examination Offers </h3>
               </div>        
   
               <div id="examSelect" class="col-12">

                     <div class=" fadeInUp selExam col-xl-4 col-lg-4 col-md-4 col-sm-6 col-xs-12" style="visibility: visible; animation-duration: 1800ms; animation-delay: 900ms;"> 
                              <img src="images/ijmb.png" class="mx-auto d-block" />
                         <div class="selExamPara">
                              <h4> IJMB </h4>
                              <p> (INTERIM JOINT MATRICULATION BOARD) </p>
                         </div>

                         <button type="button" href="#" class="mx-auto btn btn-outline-primary d-block btn-lg" data-toggle="modal" data-target="#exampleModalScrollable">read more</button>

                         <!-- Modal -->
                        <div class="modal fade" id="exampleModalScrollable" tabindex="-1" role="dialog" aria-labelledby="exampleModalScrollableTitle" aria-hidden="true">
                          <div class="modal-dialog modal-dialog-scrollable" role="document">
                            <div class="modal-content">
                              <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalScrollableTitle">IJMB (INTERIM JOINT MATRICULATION BOARD)</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                  <span aria-hidden="true">&times;</span>
                                </button>
                              </div>
                              <div class="modal-body">
                                <p> IJMB is an A level programme designed for students seeking Admission into any University of thier choice through Direct Entry into 200 level to pursue any course of thier choice.
                                IJMB is an alternative to Jamb/UTME as it affords students the priviledge to secure admission faster and easily.
                                The programme is established to provide admission for candidates who are fed-up and tired of admission denial by Universities in Nigeria of thier choice.
                                IJMB was established by the nothern Universities whisc is moderated by Ahmadu Bello University, Zaria.
                                The programme stated in the year 1973 by the Nothern Universities.
                                IJMB has provided Admission to thousands of candidates who applied for the programme.
                                Students across the Nation have benefited tremendously from the programme.
                                With IJMB, Admission into any university in Nigeria is highly guaranteed. <br> <br>

                                Admission into higher institution in nigeria has been an unending issues as students await UTME year after year hoping the next
                                UTME might be the possible solution to their admission related issue, however, national estimation has shown that UTME is not the
                                best alternative for securing admission stating that only 20% of the annual UTME candidates ends up securing admission successfully
                                with the Post UTME as Post UTME has been proved to be another barrier to securing admission into university, this simply means
                                yearly, only 320,000 out of every 1,600,000 JAMB(UTME) aspirants gain admission successfully, however it has been proven that
                                IJMB is best alternative. <br> <br>


                                IJMB is fully certified by Nigeria University Commission (NUC) as an A'level programme that serves as a mode of entry into the university today,
                                statistically as its provides a unique platform for realizing the dream of university education-even in a more efficient way than
                                JAMB because it aids in securing admission into 200 LEVEL upon completion of the programme. <strong> CHECK JAMB BROCHURE TO CONFIRM </strong></p>
                              </div>
                              <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                              </div>
                            </div>
                          </div>
                        </div>
                    </div>

                    <div class=" fadeInUp selExam col-xl-4 col-lg-4 col-md-4 col-sm-6 col-xs-12" style="visibility: visible; animation-duration: 1800ms; animation-delay: 900ms;"> 
                              <img src="images/jupeblogo.png" class="mx-auto d-block" />
                         <div class="selExamPara">
                              <h4> JUPEB </h4>
                              <p> (JOINT UNI. PRELIMINARY EXAMINATION BOARD) </p>
                         </div>

                         <button type="button" href="#" class="mx-auto btn btn-outline-primary d-block btn-lg" data-toggle="modal" data-target="#exampleModalScrollable2">read more</button>

                         <!-- Modal -->
                        <div class="modal fade" id="exampleModalScrollable2" tabindex="-1" role="dialog" aria-labelledby="exampleModalScrollableTitle2" aria-hidden="true">
                          <div class="modal-dialog modal-dialog-scrollable" role="document">
                            <div class="modal-content">
                              <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalScrollableTitle2">JUPEB (JOINT UNIVERSITY PRELIMINARY EXAMINATION BOARD)</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                  <span aria-hidden="true">&times;</span>
                                </button>
                              </div>
                              <div class="modal-body">
                                <p> The Joint Universities Preliminary Examination Board (JUPEB) is an advanced level programme established by 15 Universities in the south west which have its Central Base in University of Lagos (UNILAG).
                                  Among the Universities are University of Ibadan, Unilag, University of Nigeria NSUKA, O.A.U and all other south west and Eastern Universities.
                                  The JUPEB Programme allowes student the priviledge to secure admission into 200 Level Through Direct Entry to pursue any course of their choice in any Nigeria/Foreign Universities.
                                  The Programme was Established in the year 2013 and has helped in solving the admission stress of several Thousand of student across the country. <br> <br>




                                  Admission into higher institution in nigeria has been an unending issues as students await UTME year after year hoping the next
                                  UTME might be the possible solution to their admission related issue, however, national estimation has shown that UTME is not the
                                  best alternative for securing admission stating that only 20% of the annual UTME candidates ends up securing admission successfully
                                  with the Post UTME as Post UTME has been proved to be another barrier to securing admission into university, this simply means
                                  yearly, only 320,000 out of every 1,600,000 JAMB(UTME) aspirants gain admission successfully, however it has been proven that
                                  IJMB is best alternative. <br> <br>


                                  JUPEB is fully certified by Nigeria University Commission (NUC) as an A'level programme that serves as a mode of entry into the university today,
                                  statistically as its provides a unique platform for realizing the dream of university education-even in a more efficient way than
                                  JAMB because it aids in securing admission into 200 LEVEL upon completion of the programme. <strong> CHECK JAMB BROCHURE TO CONFIRM </strong></p>
                              </div>
                              <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                              </div>
                            </div>
                          </div>
                        </div>
                    </div>

                    <div class=" fadeInRight selExam col-xl-4 col-lg-4 col-md-4 col-sm-6 col-xs-12" style="visibility: visible; animation-duration: 1800ms; animation-delay: 900ms;"> 
                              <img src="images/jamb.png" class="mx-auto d-block" />
                         <div class="selExamPara">
                           <h4> JAMB </h4>
                            <p>(JOINT ADMISSIONS AND MATRICULATION BOARD) </p>
                         </div>
                         <!-- modal -->
                          <div class="modal fade" id="exampleModalScrollable3" tabindex="-1" role="dialog" aria-labelledby="exampleModalScrollableTitle3" aria-hidden="true">
                            <div class="modal-dialog modal-dialog-scrollable" role="document">
                              <div class="modal-content">
                                <div class="modal-header">
                                  <h5 class="modal-title" id="exampleModalScrollableTitle3">JAMB (JOINT ADMISSIONS AND MATRICULATION BOARD)</h5>
                                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                  </button>
                                </div>
                                <div class="modal-body">
                                  <p>
                                    The Joint Admissions and Matriculations Board (JAMB) is a Nigerian entrance examination board for tertiary-level institutions. The board conducts entrance Unified Tertiary Matriculation Examination for prospective undergraduates in to Nigerian universities. The board is also charged with the responsibility to administer similar examinations for applicants to Nigerian public and private monotechnics, polytechnics, and colleges of educations. All of these candidates must have obtained the West Africa School Certificate, now West African Examinations Council, WAEC, or its equivalent, National Examination Council (Nigeria), NECO.
                                  </p>
                                </div>
                                <div class="modal-footer">
                                  <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                </div>
                              </div>
                            </div>
                          </div>
                         <button type="button" href="#" class="mx-auto btn btn-outline-primary d-block btn-lg" data-toggle="modal" data-target="#exampleModalScrollable3">read more</button>    <!-- Modal -->
                     
                    </div>

                    <div class=" fadeInDown selExam col-xl-4 col-lg-4 col-md-4 col-sm-6 col-xs-12" style="visibility: visible; animation-duration: 1800ms; animation-delay: 900ms;" > 
                              <img src="images/waeclogo.png" class="mx-auto d-block" />
                         <div class="selExamPara">
                           <h4> WAEC | GCE EXAM </h4>
                            <p>(WEST AFRICAN EXAMINCATION COUNCIL) </p>
                         </div>
                         <button type="button" href="#" class="mx-auto btn btn-outline-primary d-block btn-lg" data-toggle="modal" data-target="#exampleModalScrollable4">read more</button>

                        <!-- Modal -->
                        <div class="modal fade" id="exampleModalScrollable4" tabindex="-1" role="dialog" aria-labelledby="exampleModalScrollableTitle4" aria-hidden="true">
                          <div class="modal-dialog modal-dialog-scrollable" role="document">
                            <div class="modal-content">
                              <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalScrollableTitle4">WAEC (WEST AFRICAN EXAMINCATION COUNCIL) </h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                  <span aria-hidden="true">&times;</span>
                                </button>
                              </div>
                              <div class="modal-body">
                                <p>
                                  The West African Examinations Council (WAEC) is an examination board established by law to determine the examinations required in the public interest
                                  in the English-speaking West African countries, to conduct the examinations and to award certificates comparable to those of equivalent examining authorities
                                  internationally. <br> <br>
                                  Established in 1952, the council has contributed to education in Anglophonic countries of West Africa (Ghana, Nigeria, Sierra Leone, Liberia, and the Gambia),
                                  with the number of examinations they have coordinated, and certificates they have issued. They also formed an endowment fund, to contribute to the education in West Africa,
                                  through lectures, and aid to those who cannot afford education.

                                </p>
                              </div>
                              <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                              </div>
                            </div>
                          </div>
                        </div>
                    </div>

                    <div class="fadeInRight selExam col-xl-4 col-lg-4 col-md-4 col-sm-6 col-xs-12" style="visibility: visible; animation-duration: 1800ms; animation-delay: 900ms;" > 
                              <img src="images/neco.jpg" class="mx-auto d-block" />
                         <div class="selExamPara">
                           <h4> NECO EXAM </h4>
                            <p>(NATIONAL EXAMINATION COUNCIL) </p>
                         </div>
                         <button type="button" href="#" class="mx-auto btn btn-outline-primary d-block btn-lg" data-toggle="modal" data-target="#exampleModalScrollable4">read more</button>

                         <!-- Modal -->
                          <div class="modal fade" id="exampleModalScrollable5" tabindex="-1" role="dialog" aria-labelledby="exampleModalScrollableTitle5" aria-hidden="true">
                            <div class="modal-dialog modal-dialog-scrollable" role="document">
                              <div class="modal-content">
                                <div class="modal-header">
                                  <h5 class="modal-title" id="exampleModalScrollableTitle5">NECO EXAM (NATIONAL EXAMINATION COUNCIL) </h5>
                                  <button type="button" href="#" class="mx-auto btn btn-outline-primary d-block btn-lg" data-toggle="modal" data-target="#exampleModalScrollable5">read more</button>
                                </div>
                                <div class="modal-body">
                                  <p>

                                    By its mandate, NECO was to take over the responsibilities of the National Board for Educational Measurement (NBEM) which was created, in 1992,
                                    by the Ibrahim Babangida administration, although its enabling decree was promulgated in 1993. However, the conduct of the Senior School Certificate Examinations (SSCE) which had, hitherto, been the exclusive preserve of the West African Examinations Council (WAEC) was made an additional responsibility
                                    of the new examination outfit. NECO was to take exclusive charge of the conduct of the SSCE for school based candidates while WAEC was to take charge of
                                    the same examination for private candidates. NECO was to conduct its maiden SSCE in mid 2000. <br><br>

                                    By this, as many Nigerians have the opportunity to contribute to the development of their nation and the feeling of
                                    wellbeing that results from this sense of actualization is difficult to quantify in concrete terms. <br> <br> Moreover,
                                    the greater number of family members who depend on these thousand NECO staff [and who would depend on the many more thousand potential graduates
                                    of tertiary institutions referred to earlier] means a reduction from the number of potential sources of instability in the community. <br> <br> Further,
                                    whatever resources these might be able to plough back in the form of economic activity is a potential generator of wealth in the nation. Consequently,
                                    the dividends of NECO stretch well beyond the horizon of testing, measurement or evaluation. They touch thousands of
                                    Nigerian lives and do so for the better. That, perhaps, is the greatest achievement of NECO.
                                  </p>

                                </div>
                                <div class="modal-footer">
                                  <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                </div>
                              </div>
                            </div>
                          </div>
                    </div>

                    <div class="fadeInLeft selExam col-xl-4 col-lg-4 col-md-4 col-sm-6 col-xs-12" style="visibility: visible; animation-duration: 1800ms; animation-delay: 900ms;" > 
                              <img src="images/nabteb.jpg" class="mx-auto d-block" />
                         <div class="selExamPara">
                           <h4> NABTEB EXAM </h4>
                            <p>(NATIONAL BUSINESS & TECHNICAL EXAM. BOARD) </p>
                         </div>
                         <button type="button" href="#" class="mx-auto btn btn-outline-primary d-block btn-lg" data-toggle="modal" data-target="#exampleModalScrollable6">read more</button>

                         <!-- Modal -->
                          <div class="modal fade" id="exampleModalScrollable6" tabindex="-1" role="dialog" aria-labelledby="exampleModalScrollableTitle6" aria-hidden="true">
                            <div class="modal-dialog modal-dialog-scrollable" role="document">
                              <div class="modal-content">
                                <div class="modal-header">
                                  <h5 class="modal-title" id="exampleModalScrollableTitle6">NABTEB (NATIONAL BUSINESS & TECHNICAL EXAM. BOARD)</h5>
                                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                  </button>
                                </div>
                                <div class="modal-body">
                                  <p>

                                    The National Business and Technical Examinations Board was established in 1992 to domesticate craft
                                    level examinations which were hitherto conducted by City & Guilds, Pittman's, and Royal Society of Arts all of UK in
                                    accordance with the provisions of the National Policy on Education.Its establishment was the climax of an evolutionary process which
                                    spanned 15 years from 1977 to 1992 and in which FOUR Government Panels at different times were set up to review the place and structure of
                                    public examinations in our educational system.Each of these Panels advocated and justified the multiplication of the examinations bodies, and in particular, a separate
                                    body to perform the functions which NABTEB now performs. <br> <br>
                                    The process began with the findings of Justice Sogbetun Commission of Enquiry (1978),
                                    which was set up in response to public outcry on perceived inefficiency and unchecked leakages of public examinations.

                                    This was followed by the Angulu Commission, which was set up as a result of WAEC's presentation to the House of Representative Committee on Education in 1981
                                    in which WAEC advocated the setting up of other examination boards in Nigeria "to reduce the burden of WAEC". The third was the Okoro Panel
                                    set up in 1989 to review the Angulu Report. The forth was the Professor Akin Osiyale's Task Force set up in 1991 "to evolve a strategy to
                                    reduce the burden of WAEC and bring about greater efficiency in the conduct of public examinations". <br> <br>

                                    The National Business and Technical Examinations Board (NABTEB) under Decree 70 of 1993, and other examinations bodies were thus established. Since its establishment,
                                    the findings of the Etsu Nupe Panel (1997), the Shonekan Vision 2010 (1997) Report, and the harmonized Report of the Etsu Nupe Panel and Vision
                                    2010 reports have supported, directly and indirectly, NABTEB's existence. The National headquarters of the Board is located at Ikpoba Hill,
                                    P. M. B. 1747, Benin City, and Edo State.
                                  </p>
                                </div>
                                <div class="modal-footer">
                                  <button type="button" class="btn btn-primary" data-dismiss="modal"> Close </button>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
               </div>
        </div>
       </div>

       <!-- Note: the examination offers hmtl code ends here here  -->
