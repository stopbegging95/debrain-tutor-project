<?php
if (!isset($_SERVER['HTTP_REFERER']))
   {
     header("Location: index.php");
    exit;
}

?> 


<?php include("includes/header.php"); ?>
<?php include("includes/contact.php"); ?>
  <main>
  <div class="container-fluid col-12" id="banContainerFluid" >
  <div class="container col-12 d-none d-md-block" id="banContainer">
    <div class="banner col-12">
            <img src="images/stu7.png" />
    </div>
  </div>
  <div class="container col-12" id="contactContainer">
    <div class="row col-12">
      <h3> CONTACT US :: Complain </h3>
      <div id="articleDiv" class="col-12">
                    
        <!-- <div class="col-xl-3 col-lg-3 col-md-3 col-sm-12 col-xs-12" id="artImg">
          <img src="images/logo.png" alt="ijmb image">
        </div> -->
          <div id="artText" class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12">
          <form id="complainform" class="form-control" role="form" action="<?= $_SERVER['PHP_SELF']; ?>" method="post" enctype="multipart/form-data" >
  <!-- progressbar -->
              <!-- fieldsets -->
              <fieldset class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <h2 class="complain-title"> CONTACT US </h2>
                <h3 class="complain-subtitle"> Contact us today, and get reply with in 24 hours! </h3>
                <div class="success"> <?= $success ?? ''; ?> </div>
                
                <input type="text" name="first_name" class="form-control is-valid col-xl-3 col-lg-3" id="firstName" placeholder="Surname" value="<?= $first_name ?? '' ?>" required/> <span class="error"><?= $first_name_error ?? '' ?></span>
                
                <input type="text" name="second_name" class="form-control is-valid col-xl-3 col-lg-3 " id="secondName"placeholder="Your Name" value="<?= $second_name ?? '' ?>" required/> <span class="error"><?= $second_name_error ?? '' ?></span>

                <input type="tel" name="mobile" class="form-control is-valid col-xl-3 col-lg-3" id="mobile"
                placeholder=" Valid Phone Number" value="<?= $mobile ?? '' ?>" required/>
                <span class="error"><?= $mobile_error ?? '' ?></span>

                <input type="email" name="email" class="form-control is-valid col-xl-3 col-lg-3" id="email" placeholder="Email Address" value="<?= $email ?? '' ?>" required/>
                <span class="error"><?= $email_error ?? '' ?></span>

                <input type="text" name="state_of_complain" class="form-control is-valid col-xl-3 col-lg-3" id="complain_state" placeholder="State of Compliant" value="<?= $state_complain ?? '' ?>" required/>
                <span class="error"><?= $state_complain ?? '' ?></span>

                <input type="text" name="complain_subject" class="form-control is-valid col-xl-3 col-lg-3" id="complain_subject" placeholder="Complain Subject" value="<?= $complain_subject ?? '' ?>" required/>
                <span class="error"><?= $complain_subject ?? '' ?></span>

                <textarea name="textare" id="textarea" cols="30" rows="5" class="form-control is-valid col-xl-11 col-lg-11" value="<?= $text_area ?? '' ?>" required>
                </textarea>
                <?= $text_area ?? '' ?></span>

                <button style="float:right !important;"href="#" class="action-button btn btn-block col-xl-4 col-lg-4" name="submit" value="submit" type="submit">Submit
                        </button>

              </fieldset>
            </form>
          </div>
          
      
      <!-- section for address ends here -->
            </div>
          </div>
        </div>
      </div>
  </main>
<?php include("includes/footer.php"); ?>