<div class="container-fluid" id="addOpenTouch"> 
         <div class="container col-12"> 
              <div class="time col-xl-4 col-lg-4">

              </div>
              <div class="time col-xl-4 col-lg-4">

              </div>
              <div class="time col-xl-4 col-lg-4">

              </div>
         </div>
       </div>
      