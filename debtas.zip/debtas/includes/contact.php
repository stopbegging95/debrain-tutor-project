<!-- <?php //require("include/constant.php"); ?> -->


<?php
//    if (!isset($_SERVER['HTTP_REFERER']))
//     {
//     header("Location: index.php");
//     exit;
// }

// EDIT THE 2 LINES BELOW AS REQUIRED
$email_to = "debraintutoradvancedstudies@gmail.com";
$email_subject = "Complain Contact Form";

// define veriable and set to empty value
//$photograph = $receipt_error =
$first_name_error = "";
$second_name_error = "";
$mobile_error = "";
$email_error = "";
$state_of_complain_error = "";
$complain_subject_error = "";
$text_area_error = "";


//$photograph = $receipt =
$first_name = "";
$second_name = "";
$mobile = "";
$email = "";
$state_of_complain = "";
$complain_subject = "";
$text_area = "";
$success = "";


if (isset($_POST['email'])) {
    // function died($error)
    //     {
    //         // your error code can go here
    //         echo "We are very sorry, but there were error(s) found with the form you submitted. ";
    //         echo "These errors appear below.<br /><br />";
    //         echo $error . "<br /><br />";
    //         echo "Please go back and fix these errors.<br /><br />";
    //         die();
    //     }


    if (

        !isset($_POST['first_name']) ||
        !isset($_POST['second_name']) ||
        !isset($_POST['mobile']) ||
        !isset($_POST['email']) ||
        !isset($_POST['complain_state']) ||
        !isset($_POST['complain_subject']) ||
        !isset($_POST['text_area'])
        
    ) {
        die('We are sorry, but there appears to be a problem with the form you submitted.');
    }


    $first_name = $_POST['first_name'];
    $second_name = $_POST['second_name'];
    $mobile = $_POST['mobile'];
    $email = $_POST['email'];
    $email = $_POST['complain_state'];
    $email = $_POST['complain_subject'];
    $email = $_POST['text_area'];
    
  
    if (empty($_POST['first_name'])) {
        $first_name_error = "First name is required";
    } else {
        $first_name = test_input($_POST['first_name']);
        // check if firstname only contains letters and whitespace
        if (!preg_match("/^[a-zA-Z]*$/", $first_name)) {
            $first_name_error = " Only letters and white space allowed";
        }
    }


    if (empty($_POST['second_name'])) {
        $second_name_error = "Second name is required";
    } else {
        $second_name = test_input($_POST['second_name']);
        // check if firstname only contains letters and whitespace
        if (!preg_match("/^[a-zA-Z]*$/", $second_name)) {
            $second_name_error = " Only letters and white space allowed";
        }
    }

    if (empty($_POST['mobile'])) {
        $mobile_error = "Mobile number is required";
    } else {
        $mobile = test_input($_POST['mobile']);
        // check if firstname only contains letters and whitespace
        if (!preg_match("/^(\d[\s-]?)?[\(\[\s-]{0,2}?\d{3}[\)\]\s-]{0,2}?\d{3}[\s-]?\d{4}$/i", $mobile)) {
            $mobile_error = " Only letters and white space allowed";
        }
    }


    if (empty($_POST['email'])) {
        $email_error = "Email address is required";
    } else {
        $email = test_input($_POST['email']);
        // check if email address is well-formed
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $email_error = " invalid email address required ";
        }
    }

    if (empty($_POST['state_complain'])) {
      $state_complain_error = "Second name is required";
    } else {
      $state_complain = test_input($_POST['state_complain']);
      // check if firstname only contains letters and whitespace
      if (!preg_match("/^[a-zA-Z]*$/", $state_complain)) {
          $state_complain_error = " Only letters and white space allowed";
      }
    }

    if (empty($_POST['complain_subject'])) {
      $complain_subject_error = "Second name is required";
    } else {
      $complain_subject = test_input($_POST['complain_subject']);
      // check if firstname only contains letters and whitespace
      if (!preg_match("/^[a-zA-Z]*$/", $complain_subject)) {
          $complain_subject_error = " Only letters and white space allowed";
      }
  }

    if (empty($_POST['text_area'])) {
        $text_area_error = "Home address is required";
    } else {
        $text_area = test_input($_POST['text_area']);
        // check if firstname only contains letters and whitespace
        if (!preg_match("/^[a-zA-Z]*$/", $text_area)) {
            $text_area_error = " ";
        }
    }

  
    function clean_string($string)
    {
        $bad = array("content-type", "bcc:", "to:", "cc:", "href");
        return str_replace($bad, "", $string);
    } 

    $email_message = "Form details below.\n\n";

    $email_message .= "First Name: " . clean_string($first_name) . "\n";
    $email_message .= "Second Name: " . clean_string($second_name) . "\n";
    $email_message .= "Mobile: " . clean_string($mobile) . "\n";
    $email_message .= "Email: " . clean_string($email) . "\n";
    $email_message .= "State of complain: " . clean_string($state_complain) . "\n";
    $email_message .= "Complain Subject: " . clean_string($complain_subject) . "\n";
    $email_message .= "Complain: " . clean_string($text_area) . "\n";
    // TODO add link to folder where you store all your images

    //$email_message .= "photograph: " .  $server_file_location. "\n"; 

    $headers = 'From: ' . $first_name . $second_name . $mobile . $email . $complain_subject . "\r\n" .
        'Reply-To: ' . $email . "\r\n" .
        'X-Mailer: PHP/' . phpversion();
    $subject = "Contact Form Submit";
    if (mail($email_to, $email_subject, $email_message, $headers)) {
        $success = "Application Completed Successfully, Check Your Email For Printouts ";
        $first_name = $second_name = $mobile = $email =  $state_complain = $complain_subject = $text_area = " ";
    } else {
        $success = "ERROR Form Not Submitted Check Your Connection!";
    }


}

function test_input($date)
{
    $date = trim($date);
    $date = stripcslashes($date);
    $date = htmlspecialchars($date);
    return $date;
}


// if (mysqli_query($connection, $sql)) {
//     echo "Records added successfully.";
//     header('Location: success.php');
// } else {
//     echo "ERROR: Could not able to execute $sql. " . mysqli_error($connection);
// }


// close connection
//mysqli_close($connection);

?>
