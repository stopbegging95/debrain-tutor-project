<footer>
     	<div class="container col-12">
     		<div class="row col-12">

                    <div class="footerDiv col-xl-5 col-lg-5 col-md-6" id="newsLet">
                         <h4> Our New Letter</h4>
                         <div class="col-12">

                              <h4> Subscribe To Our News Letter </h4>
                              <p> <em> for more news updates... </em> </p>

                         </div>

                         <div class=" newsLetterPara col-12">

                              <section>

                                   <form class="form-group col-10" >
                                        <!-- <i class="fa fa-paper-plane d-none d-block-sm"></i> -->
                                        <input type="email" class="form-control" placeholder="Enter your email" id="email" name="email">
                                        
                                        <a href="#" class="btn btn-primary btn-lg active" role="button" aria-pressed="true"> Subscribe</a>

                                   </form>
                              </section>
                         </div>
                    </div>

                    <div class="footerDiv col-xl-3 col-lg-3 col-md-6">
                         <h4> Head Office</h4>
                    
                              <p> <span class="fa fa-home"> Address: </span> <br> 9, Kulende Before Harmony Estate Sango Ilorin,  Kwara State.  </p>

                              <p> <span class="fa fa-headphones"> Hot lines: </span> <br> 08165371302 09078504153 09059971709  </p>

                              <!-- <p> <span class="fa fa-envelope"> Email: </span> <br>debraintutoradvancedstudies@gmail.com  </p> -->


                         <h5> Branch Offices </h5>

                              <ul id="branchul">
                                   <li>Lagos Ikeja || Ogun State</li>
                                   <li>Oyo State   || Rivers State</li>
                                   <li>Delta State || FCT Abuja</li>
                              </ul>
                    </div>
                   
                    <div class="footerDiv col-xl-2 col-lg-2 col-md-6">
                         <h4> Quick Links</h4>
                         <ul id="Quickul">
                              <li class="quickli"> <a href="#"> Our Blog </a></li>
                              <li class="quickli"> <a href="faq.php"> FAQs </a></li>  
                              <li class="quickli"> <a href="applicationform.php"> Online Registration </a></li>    
                         </ul>
                    </div>

                    <div class="footerDiv col-xl-2 col-lg-2 col-md-6">
                         <h4> Follow Us</h4>
                         <ul>
                              <li> <a target="_blank" href="https://www.facebook.com/debrain.tutor.5" id="facebook"> <span class="fa fa-facebook" ></span>  </a></li>
                              <li> <a target="_blank" href="https://wa.me/09078504153" id="whatsapp"> <span class="fa fa-whatsapp" ></span>  </a></li>
                              <li> <a href="#" id="instagram" > <span class="fa fa-instagram" ></span>  </a></li>
                              <li> <a target="_blank" href="https://www.twitter.com/debraintutor" id="twitter" > <span class="fa fa-twitter" ></span>  </a>
                              </li>
                         </ul>
                    </div>

                    
     			<div class="col-xs-12 col-sm-8 col-md-8 col-lg-8 bottomFooter">
     				<p>&copy;
                              <?php echo date("Y"); ?> 
                              all rights reserved. DEBTAS </p>
     			</div>
     			<div class="text-right col-xs-12 col-sm-4 col-md-4 col-lg-4 bottomFooter">
     				<p>Developed by <a href="httpS://www.cinsol.com.ng/" title=" CINSOL"> CINSOL </a> </p>
     			</div>
     		</div>
     	</div>
     </footer>
	 <script type="text/javascript" src="scripts/jquery-3.3.1.min.js"></script>
     <script type="text/javascript" src="scripts/popper.min.js"></script>
     <script type="text/javascript" src="scripts/bootstrap.min.js"></script>
     <script type="text/javascript" src="scripts/jquery-ui.min.js"></script>
     <script type="text/javascript" src="scripts/list.min.js"></script>
     <script type="text/javascript" src="scripts/slick.js"></script>
     <script type="text/javascript" src="scripts/jsScript.js"></script>
     <script type="text/javascript" src="scripts/wow.min.js"></script>
     <script type="text/javascript">
          var wow = new WOW(
               {
                    boxClass: 'wow',      // animated element css class (default is wow)
                    animateClass: 'animated', // animation css class (default is animated)
                    offset: 0,          // distance to the element when triggering the animation (default is 0)
                    mobile: true,       // trigger animations on mobile devices (default is true)
                    live: true,       // act on asynchronously loaded content (default is true)
                    callback: function (box) {
                         // the callback is fired every time an animation is started
                         // the argument that is passed in is the DOM node being animated
                    },
                    scrollContainer: null // optional scroll container selector, otherwise use window
               }
          );
          wow.init();
     </script>
     <!-- #BeginEditable "scripts" -->

	<!-- #EndEditable -->
	<script src="https://www.google.com/recaptcha/api.js" async defer></script>
</body>

</html>
