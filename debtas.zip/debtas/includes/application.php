<!-- <?php //require("include/constant.php"); ?> -->


<?php
   if (!isset($_SERVER['HTTP_REFERER']))
    {
    header("Location: index.php");
    exit;
}

// EDIT THE 2 LINES BELOW AS REQUIRED
$email_to = "debraintutoradvancedstudies@gmail.com";
$email_subject = "Application Form";

// define veriable and set to empty value
//$photograph = $receipt_error =
$first_name_error = "";
$second_name_error = "";
$middle_name_error = "";
$date_of_birth_error = "";
$sex_error = "";
$state_of_origine_error = "";
$localgovarea_error = "";
$mobile_error = "";
$email_error = "";
$home_address_error = "";
$select_prog_error = "";
$department_error = "";
$course_error = "";
$olevel_res_error = "";
// $title_error = "";
$guardian_first_name_error = "";
$guardian_second_name_error = "";
$guardian_middle_name_error = "";
$guardian_date_of_birth_error = "";
$guardian_sex_error = "";
$guardian_state_of_origine_error = "";
$guardian_localgovarea_error = "";
$guardian_mobile_error = "";
$guardian_email_error = "";
$guardian_home_address_error = "";


//$photograph = $receipt =
$first_name = "";
$second_name = "";
$middle_name = "";
$date_of_birth = "";
$sex = "";
$state_of_origine = "";
$localgovarea = "";
$mobile = "";
$email = "";
$home_address = "";
$select_prog = "";
$department = "";
$course = "";
$olevel_res = "";
// $title = "";
$guardian_first_name = "";
$guardian_second_name = "";
$guardian_middle_name = "";
$guardian_date_of_birth = "";
$guardian_sex = "";
$guardian_state_of_origine = "";
$guardian_localgovarea = "";
$guardian_mobile = "";
$guardian_email = "";
$guardian_home_address = "";
$success = "";


if (isset($_POST['email'])) {
    // function died($error)
    //     {
    //         // your error code can go here
    //         echo "We are very sorry, but there were error(s) found with the form you submitted. ";
    //         echo "These errors appear below.<br /><br />";
    //         echo $error . "<br /><br />";
    //         echo "Please go back and fix these errors.<br /><br />";
    //         die();
    //     }


    if (

        !isset($_POST['first_name']) ||
        !isset($_POST['second_name']) ||
        !isset($_POST['middle_name']) ||
        !isset($_POST['date_of_birth']) ||
        !isset($_POST['sex']) ||
        !isset($_POST['state_of_origine']) ||
        !isset($_POST['localgovarea']) ||
        !isset($_POST['mobile']) ||
        !isset($_POST['email']) ||
        !isset($_POST['home_address']) ||
        !isset($_POST['select_prog']) ||
        !isset($_POST['department']) ||
        !isset($_POST['course']) ||
        !isset($_POST['olevel_res']) ||
        // !isset($_POST['title']) ||
        !isset($_POST['guardian_first_name']) ||
        !isset($_POST['guardian_second_name']) ||
        !isset($_POST['guardian_middle_name']) ||
        !isset($_POST['guardian_date_of_birth']) ||
        !isset($_POST['guardian_sex']) ||
        !isset($_POST['guardian_state_of_origine']) ||
        !isset($_POST['guardian_localgovarea']) ||
        !isset($_POST['guardian_mobile']) ||
        !isset($_POST['guardian_email']) ||
        !isset($_POST['guardian_home_address'])
        // !isset($_POST['photograph'])

    ) {
        die('We are sorry, but there appears to be a problem with the form you submitted.');
    }


    $first_name = $_POST['first_name'];
    $second_name = $_POST['second_name'];
    $middle_name = $_POST['middle_name'];
    $date_of_birth = $_POST['date_of_birth'];
    $sex = $_POST['sex'];
    $state_of_origine = $_POST['state_of_origine'];
    $localgovarea = $_POST['localgovarea'];
    $mobile = $_POST['mobile'];
    $email = $_POST['email'];
    $home_address = $_POST['home_address'];
    $select_prog = $_POST['select_prog'];
    $department = $_POST['department'];
    $course = $_POST['course'];
    $olevel_res = $_POST['olevel_res'];
    // $title = $_POST['title'];
    $guardian_first_name = $_POST['guardian_first_name'];
    $guardian_second_name = $_POST['guardian_second_name'];
    $guardian_middle_name = $_POST['guardian_middle_name'];
    $guardian_date_of_birth = $_POST['guardian_date_of_birth'];
    $guardian_sex = $_POST['guardian_sex'];
    $guardian_state_of_origine = $_POST['guardian_state_of_origine'];
    $guardian_localgovarea = $_POST['guardian_localgovarea'];
    $guardian_mobile = $_POST['mobile'];
    $guardian_email = $_POST['guardian_email'];
    $guardian_home_address = $_POST['guardian_home_address'];
    // $photograph = $_FILES['photograph'];


    // Get Image Dimension
    // $fileinfo = @getimagesize($_FILES["photograph"]["tmp_name"]);
    // $width = $fileinfo[0];
    // $height = $fileinfo[1];

    // $allowed_image_extension = array(
    //     "png",
    //     "jpg",
    //     "jpeg"
    // );

    //Get image file extension
    // $file_extension = pathinfo($_FILES["photograph"]["name"], PATHINFO_EXTENSION);

    // //Validate file input to check if is not empty
    // if (!file_exists($_FILES["photograph"]["tmp_name"])) {
    //     $response = array(
    //         "type" => "error",
    //         "message" => "Choose image file to upload."
    //     );
    // }    // Validate file input to check if is with valid extension
    // else if (!in_array($file_extension, $allowed_image_extension)) {
    //     $response = array(
    //         "type" => "error",
    //         "message" => "Upload valid images. Only PNG and JPEG are allowed."
    //     );
    //     echo $result;
    // }    // Validate image file size
    // else if (($_FILES["photograph"]["size"] > 2000000)) {
    //     $response = array(
    //         "type" => "error",
    //         "message" => "Image size exceeds 2MB"
    //     );
    // }    // Validate image file dimension
    // else ($width > "300" || $height > "200"){
    // $response = array(
    //     "type" => "error",
    //     "message" => "Image dimension should be within 300X200"
    // )
    // };


    // if (!file_exists($_FILES["photograph"]["tmp_name"])) {
    //     $response = array(
    //         "type" => "error",
    //         "message" => "Choose image file to upload."
    //     );
    // }


//     if (empty($_FILES['photograph'])) {
//         $photograph_error = "Passport required";
//     } else {
//         $photograph = test_input($_FILES['photograph']['name']);
//         // check if firstname only contains letters and whitespace
// //         ,
//         if (!preg_match("^[^?]*\.(jpg|jpeg|gif|png)", $photograph)) {
//             $photograph_error = "";
    //     }
    // }

    if (empty($_POST['first_name'])) {
        $first_name_error = "First name is required";
    } else {
        $first_name = test_input($_POST['first_name']);
        // check if firstname only contains letters and whitespace
        if (!preg_match("/^[a-zA-Z]*$/", $first_name)) {
            $first_name_error = " Only letters and white space allowed";
        }
    }


    if (empty($_POST['second_name'])) {
        $second_name_error = "Second name is required";
    } else {
        $second_name = test_input($_POST['second_name']);
        // check if firstname only contains letters and whitespace
        if (!preg_match("/^[a-zA-Z]*$/", $second_name)) {
            $second_name_error = " Only letters and white space allowed";
        }
    }


    if (empty($_POST['middle_name'])) {
        $middle_name_error = "Last name is required";
    } else {
        $middle_name = test_input($_POST['middle_name']);
        // check if firstname only contains letters and whitespace
        if (!preg_match("/^[a-zA-Z]*$/", $middle_name)) {
            $middle_name_error = " Only letters and white space allowed";
        }
    }


    if (empty($_POST['sex'])) {
        $sex_error = "Gender is required";
    } else {
        $sex = test_input($_POST['sex']);
        // check if firstname only contains letters and whitespace
        if (!preg_match("/^[a-zA-Z]*$/", $sex)) {
            $sex_error = " Only letters and white space allowed";
        }
    }


    if (empty($_POST['state_of_origine'])) {
        $state_of_origine_error = "State of origine is required";
    } else {
        $state_of_origine = test_input($_POST['state_of_origine']);
        // check if firstname only contains letters and whitespace
        if (!preg_match("/^[a-zA-Z]*$/", $state_of_origine)) {
            $state_of_origine_error = " Only letters and white space allowed";
        }
    }


    if (empty($_POST['localgovarea'])) {
        $localgovarea_error = "Local Governent name is required";
    } else {
        $localgovarea = test_input($_POST['localgovarea']);
        // check if firstname only contains letters and whitespace
        if (!preg_match("/^[a-zA-Z]*$/", $localgovarea)) {
            $localgovarea_error = " ";
        }
    }


    if (empty($_POST['mobile'])) {
        $mobile_error = "Mobile number is required";
    } else {
        $mobile = test_input($_POST['mobile']);
        // check if firstname only contains letters and whitespace
        if (!preg_match("/^(\d[\s-]?)?[\(\[\s-]{0,2}?\d{3}[\)\]\s-]{0,2}?\d{3}[\s-]?\d{4}$/i", $mobile)) {
            $mobile_error = " Only letters and white space allowed";
        }
    }


    if (empty($_POST['email'])) {
        $email_error = "Email address is required";
    } else {
        $email = test_input($_POST['email']);
        // check if email address is well-formed
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $email_error = " invalid email address required ";
        }
    }

    if (empty($_POST['home_address'])) {
        $home_address_error = "Home address is required";
    } else {
        $home_address = test_input($_POST['home_address']);
        // check if firstname only contains letters and whitespace
        if (!preg_match("/^[a-zA-Z]*$/", $home_address)) {
            $home_address_error = " ";
        }
    }


    if (empty($_POST['select_prog'])) {
        $select_prog_error = "Programme selection is required";
    } else {
        $select_prog = test_input($_POST['select_prog']);
        // check if firstname only contains letters and whitespace
        if (!preg_match("/^[a-zA-Z]*$/", $select_prog)) {
            $select_prog_error = " Only letters and white space allowed";
        }
    }


    if (empty($_POST['department'])) {
        $department_error = "Department is required";
    } else {
        $department = test_input($_POST['department']);
        // check if firstname only contains letters and whitespace
        if (!preg_match("/^[a-zA-Z]*$/", $department)) {
            $department_error = " Only letters and white space allowed";
        }
    }


    if (empty($_POST['course'])) {
        $course_error = "Course is required";
    } else {
        $course = test_input($_POST['course']);
        // check if firstname only contains letters and whitespace
        if (!preg_match("/^[a-zA-Z]*$/", $course)) {
            $course_error = " Only letters and white space allowed";
        }
    }


    if (empty($_POST['olevel_res'])) {
        $olevel_res_error = "Olevel is required";
    } else {
        $olevel_res = test_input($_POST['olevel_res']);
        // check if firstname only contains letters and whitespace
        if (!preg_match("/^[a-zA-Z]*$/", $olevel_res)) {
            $olevel_res_error = " Only letters and white space allowed";
        }
    }

    // if (empty($_POST['title'])) {
    //     $title_error = "Title is required";
    // } else {
    //     $title = test_input($_POST['title']);
    //     // check if firstname only contains letters and whitespace
    //     if (!preg_match("/^[a-zA-Z]*$/", $title)) {
    //         $title_error = " Only letters and white space allowed";
    //     }
    // }


    if (empty($_POST['guardian_first_name'])) {
        $guardian_first_name_error = "Guardian first name is required";
    } else {
        $guardian_first_name = test_input($_POST['guardian_first_name']);
        // check if firstname only contains letters and whitespace
        if (!preg_match("/^[a-zA-Z]*$/", $guardian_first_name)) {
            $guardian_first_name_error = "Only letters and white space allowed ";
        }
    }


    if (empty($_POST['guardian_second_name'])) {
        $guardian_second_name_error = "Guardian second name is required";
    } else {
        $guardian_second_name = test_input($_POST['guardian_second_name']);
        // check if firstname only contains letters and whitespace
        if (!preg_match("/^[a-zA-Z]*$/", $guardian_second_name)) {
            $guardian_second_name_error = " Only letters and white space allowed ";
        }
    }


    if (empty($_POST['guardian_middle_name'])) {
        $guardian_middle_name_error = "Guardian middle name is required";
    } else {
        $guardian_middle_name = test_input($_POST['guardian_middle_name']);
        // check if firstname only contains letters and whitespace
        if (!preg_match("/^[a-zA-Z]*$/", $guardian_middle_name)) {
            $guardian_middle_name_error = " Only letters and white space allowed ";
        }
    }


    if (empty($_POST['guardian_sex'])) {
        $guardian_sex_error = "Guardian  Gender is required";
    } else {
        $guardian_sex = test_input($_POST['guardian_sex']);
        // check if firstname only contains letters and whitespace
        if (!preg_match("/^[a-zA-Z]*$/", $guardian_sex)) {
            $guardian_sex_error = " Only letters and white space allowed";
        }
    }


    if (empty($_POST['guardian_state_of_origine'])) {
        $guardian_state_of_origine_error = "Guardian state of origine is required";
    } else {
        $guardian_state_of_origine = test_input($_POST['guardian_state_of_origine']);
        // check if firstname only contains letters and whitespace
        if (!preg_match("/^[a-zA-Z]*$/", $guardian_state_of_origine)) {
            $guardian_state_of_origine_error = " Only letters and white space allowed";
        }
    }


    if (empty($_POST['guardian_localgovarea'])) {
        $guardian_localgovarea_error = "Guardian Local Government is required";
    } else {
        $guardian_localgovarea = test_input($_POST['guardian_localgovarea']);
        // check if firstname only contains letters and whitespace
        if (!preg_match("/^[a-zA-Z]*$/", $guardian_localgovarea)) {
            $guardian_localgovarea_error = " ";
        }
    }


    if (empty($_POST['guardian_mobile'])) {
        $guardian_mobile_error = "Guardian mobile is required";
    } else {
        $guardian_mobile = test_input($_POST['guardian_mobile']);
        // check if firstname only contains letters and whitespace
        if (!preg_match("/^(\d[\s-]?)?[\(\[\s-]{0,2}?\d{3}[\)\]\s-]{0,2}?\d{3}[\s-]?\d{4}$/i", $guardian_mobile)) {
            $guardian_mobile_error = " Only letters and white space allowed";
        }
    }


    if (empty($_POST['guardian_email'])) {
        $guardian_email_error = "Guardian email address is required";
    } else {
        $guardian_email = test_input($_POST['guardian_email']);
        // check if email address is well-formed
        if (!filter_var($guardian_email, FILTER_VALIDATE_EMAIL)) {
            $guardian_email_error = " invalid email address required ";
        }
    }

    if (empty($_POST['guardian_home_address'])) {
        $guardian_home_address_error = "Guardian home address is required";
    } else {
        $guardian_home_address = test_input($_POST['guardian_home_address']);
        // check if firstname only contains letters and whitespace
        if (!preg_match("/^[a-zA-Z]*$/", $guardian_home_address)) {
            $guardian_home_address_error = " ";
        }
    }
 

    // EVERY THING IS OK AND ITS TIME TO UPLOAD IMAGE
//     $target_dir = "/uploads/";
// $target_file = $target_dir . basename($_FILES["photograph"]["name"]);
// $server_file_location =  $_SERVER['DOCUMENT_ROOT'].$target_file;
 


// if (!file_exists($server_file_location)) {
//    move_uploaded_file($_FILES["photograph"]["tmp_name"], $target_file);
//     }


    function clean_string($string)
    {
        $bad = array("content-type", "bcc:", "to:", "cc:", "href");
        return str_replace($bad, "", $string);
    } 

    $email_message = "Form details below.\n\n";

    $email_message .= "First Name: " . clean_string($first_name) . "\n";
    $email_message .= "Second Name: " . clean_string($second_name) . "\n";
    $email_message .= "Middle Name: " . clean_string($middle_name) . "\n";
    $email_message .= "Date of Birth: " . clean_string($date_of_birth) . "\n";
    $email_message .= "Sex: " . clean_string($sex) . "\n";
    $email_message .= "State Of Origine: " . clean_string($state_of_origine) . "\n";
    $email_message .= "Localgovarea: " . clean_string($localgovarea) . "\n";
    $email_message .= "Mobile: " . clean_string($mobile) . "\n";
    $email_message .= "Email: " . clean_string($email) . "\n";
    $email_message .= "Home Address: " . clean_string($home_address) . "\n";
    $email_message .= "Select Programe: " . clean_string($select_prog) . "\n";
    $email_message .= "Department: " . clean_string($department) . "\n";
    $email_message .= "Course: " . clean_string($course) . "\n";
    $email_message .= "Olevel Result: " . clean_string($olevel_res) . "\n";
    // $email_message .= "Title: " . clean_string($title) . "\n";
    $email_message .= "Guardian First Name: " . clean_string($guardian_first_name) . "\n";
    $email_message .= "Guardian Second Name: " . clean_string($guardian_second_name) . "\n";
    $email_message .= "Guardian Middle Name: " . clean_string($guardian_middle_name) . "\n";
    $email_message .= "Guardian Date of Birth: " . clean_string($guardian_date_of_birth) . "\n";
    $email_message .= "Guardian Sex: " . clean_string($guardian_sex) . "\n";
    $email_message .= "Guardian State of Origine: " . clean_string($guardian_state_of_origine) . "\n";
    $email_message .= "Guardian Local Gov Area: " . clean_string($guardian_localgovarea) . "\n";
    $email_message .= "Guardian Mobile: " . clean_string($guardian_mobile) . "\n";
    $email_message .= "Guardian Email: " . clean_string($guardian_email) . "\n";
    $email_message .= "Guardian Home Address: " . clean_string($guardian_home_address) . "\n";
    // TODO add link to folder where you store all your images

    //$email_message .= "photograph: " .  $server_file_location. "\n"; 

    $headers = 'From: ' . $first_name . $second_name . $middle_name . "\r\n" .
        'Reply-To: ' . $email . "\r\n" .
        'X-Mailer: PHP/' . phpversion();
    $subject = "Contact Form Submit";
    if (mail($email_to, $email_subject, $email_message, $headers)) {
        $success = "Application Completed Successfully, Check Your Email For Printouts ";
        $first_name = $second_name = $middle_name = $date_of_birth = $sex = $state_of_origine = $localgovarea = $mobile = $email = $home_address = $select_prog = $department = $course = $olevel_res = $guardian_first_name = $guardian_second_name = $guardian_middle_name = $guardian_date_of_birth = $guardian_sex = $guardian_state_of_origine = $guardian_localgovarea = $guardian_mobile = $guardian_email = $guardian_home_address = " ";
    } else {
        $success = "ERROR Form Not Submitted Check Your Connection!";
    }

    // create email headers
    //I changed this $email to $name
    // $headers = 'From: ' . $first_name . $second_name . $middle_name . "\r\n" .
    //  'Reply-To: ' . $email . "\r\n" .
    //  'X-Mailer: PHP/' . phpversion();
    // @mail($email_to, $email_subject, $email_message, $headers);
    // echo  "<h1 style='color: green; margin:20px;'> The Information has been received, we will get back to you shortly. <h1>";


}

function test_input($date)
{
    $date = trim($date);
    $date = stripcslashes($date);
    $date = htmlspecialchars($date);
    return $date;
}


// NOTE THIS CODE IS WORKING FOR FORM SUBMISSION TO SQL DATABASE AND IT IS WORKING VERY WELL

// create a connection to database
//$connection = mysqli_connect(DB_SERVER, DB_USER, DB_PASS, DB_NAME);

// Check connection
//if (!$connection) {
//die("Database connection failed: " . mysql_error());
//}

// select a database to use
//$db_select = mysqli_select_db($connection, DB_NAME);
//if(!$db_select) {
//die("Database selection failed: " . mysqli_error($connection));
//}


// Escape user inputs for security
// if (  isset($_FILES['photograph']) ||  isset($_POST['receipt']) || isset($_POST['first_name'])  || isset($_POST['second_name']) || isset($_POST['middle_name']) || isset($_POST['date_of_birth']) || isset($_POST['sex'])  || isset($_POST['state_of_origine']) || isset($_POST['localgovarea']) || isset($_POST['mobile']) || isset($_POST['email']) || isset($_POST['home_address']) || isset($_POST['select_prog']) || isset($_POST['department']) || isset($_POST['course']) || isset($_POST['olevel_res']) || isset($_POST['title']) || isset($_POST['guardian_first_name']) || isset($_POST['guardian_second_name']) || isset($_POST['guardian_middle_name']) || isset($_POST['guardian_date_of_birth']) || isset($_POST['guardian_sex']) || isset($_POST['guardian_state_of_origine']) || isset($_POST['guardian_localgovarea'])  ||  isset($_POST['mobile']) || isset($_POST['guardian_email']) || isset($_POST['guardian_home_address'])) {


//          $photograph = mysqli_real_escape_string($connection, $_FILES['photograph']);
//          $receipt = mysqli_real_escape_string($connection, $_POST['receipt']);
//          $first_name = mysqli_real_escape_string($connection, $_POST['first_name']);
//          $second_name = mysqli_real_escape_string($connection, $_POST['second_name']);
//          $middle_name = mysqli_real_escape_string($connection,$_POST['middle_name']);
//          $date_of_birth = mysqli_real_escape_string($connection, $_POST['date_of_birth']);
//          $sex = mysqli_real_escape_string($connection, $_POST['sex']);
//          $state_of_origine = mysqli_real_escape_string($connection, $_POST['state_of_origine']);
//          $localgovarea = mysqli_real_escape_string($connection, $_POST['localgovarea']);
//          $mobile = mysqli_real_escape_string($connection, $_POST['mobile']);
//          $email = mysqli_real_escape_string($connection, $_POST['email']);
//          $home_address = mysqli_real_escape_string($connection, $_POST['home_address']);
//          $select_prog = mysqli_real_escape_string($connection, $_POST['select_prog']);
//          $department = mysqli_real_escape_string($connection, $_POST['department']);
//          $course = mysqli_real_escape_string($connection, $_POST['course']);
//          $olevel_res = mysqli_real_escape_string($connection, $_POST['olevel_res']);
//          $title = mysqli_real_escape_string($connection, $_POST['title']);
//          $guardian_first_name = mysqli_real_escape_string($connection, $_POST['guardian_first_name']);
//          $guardian_second_name = mysqli_real_escape_string($connection, $_POST['guardian_second_name']);
//          $guardian_middle_name = mysqli_real_escape_string($connection, $_POST['guardian_middle_name']);
//          $guardian_date_of_birth = mysqli_real_escape_string($connection, $_POST['guardian_date_of_birth']);
//          $guardian_sex = mysqli_real_escape_string($connection, $_POST['guardian_sex']);
//          $guardian_state_of_origine = mysqli_real_escape_string($connection, $_POST['guardian_state_of_origine']);
//          $guardian_localgovarea = mysqli_real_escape_string($connection, $_POST['guardian_localgovarea']);
//          $guardian_mobile = mysqli_real_escape_string($connection, $_POST['mobile']);
//          $guardian_email = mysqli_real_escape_string($connection, $_POST['guardian_email']);
//          $guardian_home_address = mysqli_real_escape_string($connection, $_POST['guardian_home_address']);

// }
// attempt insert query execution

// $sql = "INSERT INTO applicationform (photograph, receipt, first_name, second_name, middle_name, date_of_birth, sex, state_of_origine, localgovarea, mobile, email, home_address, select_prog, department, course, olevel_res, title, guardian_first_name, guardian_second_name, guardian_middle_name, guardian_date_of_birth, guardian_sex, guardian_state_of_origine, guardian_localgovarea, guardian_mobile, guardian_email, guardian_home_address)
//  VALUES ('$photograph', '$receipt', '$first_name', '$second_name', '$middle_name',  '$date_of_birth', '$sex', '$state_of_origine', '$localgovarea', '$mobile', '$email', '$home_address', '$select_prog', '$department', '$course', '$olevel_res', '$title', '$guardian_first_name', '$guardian_second_name', '$guardian_middle_name', 'guardian_date_of_birth', '$guardian_sex', '$guardian_state_of_origine', '$guardian_localgovarea', '$guardian_mobile', '$guardian_email', '$guardian_home_address')";


// if (mysqli_query($connection, $sql)) {
//     echo "Records added successfully.";
//     header('Location: success.php');
// } else {
//     echo "ERROR: Could not able to execute $sql. " . mysqli_error($connection);
// }


// close connection
//mysqli_close($connection);

?>
