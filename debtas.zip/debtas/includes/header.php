<!DOCTYPE html>
<html>

<head>
<meta content="text/html; charset=utf-8" http-equiv="Content-Type" />
<title> DEBTAS INSTITUTE </title>
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<meta name="keywords" content="A'level, IJMB, JUPEB, IJMB Website in Nigeria, IJMB Website in Lagos, IJMB Website in Ogun, IJMB Website in Ilorin, IJMB Website in Kwara, IJMB Website in Osun,  IJMB Center in Nigeria, IJMB Center in Lagos, IJMB Center in Ogun, IJMB Center in Ilorin, IJMB Center in Kwara, IJMB Center in Osun, JUPEB Website in Nigeria, JUPEB Website in Lagos, JUPEB Website in Ogun, JUPEB Website in Ilorin, JUPEB Website in Kwara, JUPEB Website in Osun,  JUPEB Center in Nigeria, JUPEB Center in Lagos, JUPEB Center in Ogun, JUPEB Center in Ilorin, JUPEB Center in Kwara, JUPEB Center in Osun, equipements" />
<meta name="description" content="DE-BRAIN-TUTOR ADVANCED STUDIES EDUCATIONAL SERVICES is establish to solve solutions on academics, for both student in the Secondary Secondary School, and (S.S.C.E.) graduate looking forward to gain admission in to any university of their choice among Nigieria University." />

<link rel="shortcut icon" href="images/logo.png" type="image/x-icon" />

<link href="styles/fonts.css" rel="stylesheet" />
<link href="styles/bootstrap.min.css" rel="stylesheet" />
<link href="styles/jquery-ui.min.css" rel="stylesheet" />
<link href="styles/myglyphicons2.css" rel="stylesheet" />
<link href="styles/font-awesome.css" rel="stylesheet" />
<link href="styles/site.css" rel="stylesheet" />
<link href="styles/animate.css" rel="stylesheet" />

<!-- #BeginEditable "styles" -->

<!-- #EndEditable -->
</head>
<body>
<header>
     <div id="uppernav">
               <div class="container-fluid" id="upperNavFluid">
                    <div class="row col-xl-7 col-lg-8 col-md-8 col-sm-8 col-xs-12"  id="row1" >
                         <p> Need help? <span class="fa fa-headphones"></span>  09059971709 || 08165371302 || <span class="fa fa-whatsapp"> </span> 09078504153 </p>
                    </div>
                    <div class="row col-xl-5 col-lg-4 col-md-4 col-sm-4 col-xs-12 d-none d-sm-block" id="row2" >
                    <!-- <p class="ml-auto "> Already have an account? <span class="fa fa-sign-in">  <a style="color: white" href="#"> </span> Login </a> |<a style="color: white" href="#"> Register </a> </p> -->

                         <p class="ml-auto "> <a style="color: white" href="#"> Login </a> | <a style="color: white" href="#"> Online Register </a> </p>
                         
                    </div>
               </div>
     </div>
     
     
	<div class="container col-12">
     	<nav class="navbar navbar-expand-lg col-12">
               <a class="navbar-brand" href="/">
                    <img class="img-fluid" src="images/logo1.jpg" />
               </a>
               <button class="navbar-toggler navbar-dark btn-unique" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
               </button>

               <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="ml-auto navbar-nav">
                         <li class="nav-item active">
                              <a class="nav-link" href="index.php"> Home <span class="sr-only">(current)</span></a>
                         </li>
                         <li class="nav-item dropdown">
                              <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> About Us
                              </a>
                              <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                                   <a class="dropdown-item" href="about.php"> Who We Are</a>
                                   <a class="dropdown-item" href="ourteam.php"> Our Team</a>
                              </div>
                         </li>
                         <li class="nav-item dropdown">
                              <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> A'level
                              </a>
                              <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                                   <a class="dropdown-item" href="ourcourses.php"> Courses </a>
                                   <a class="dropdown-item" href="lecturecenter.php"> Lecture centers</a>
                                   <a class="dropdown-item" href="schoolfees.php"> School fees</a>
                                   <a class="dropdown-item" href="subjectgrades.php"> Subjects and Grades</a>
                                   <a class="dropdown-item" href="accepteduniversity.php"> Accepted University</a>
                              </div>
                         </li>
                         <li class="nav-item dropdown">
                              <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> International Exams
                              </a>
                              <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                                   <a class="dropdown-item" href="#"> IELTS Exam </a>
                                   <a class="dropdown-item" href="#"> TOEFL Exam</a>
                                   <a class="dropdown-item" href="#"> SAT Exam</a>
                                   <a class="dropdown-item" href="#"> GRE Exam</a>
                                   <a class="dropdown-item" href="#"> GMATH </a>
                              </div>
                         </li>
                         <li class="nav-item">
                              <a class="nav-link" href="onlineregistration.php"> Online Registration</a>
                         </li>
                         <!-- <li class="nav-item">
                              <a class="nav-link" href="gallery.php"> Gallery</a>
                         </li> -->
                         <li class="nav-item">
                              <a class="nav-link" href="contactus.php"> Contact Us</a>
                         </li>
                         <li class="nav-item dropdown">
                              <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> Faq & Blog
                              </a>
                              <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                                   <a class="dropdown-item" href="faq.php"> Faq</a>
                                   <a class="dropdown-item" href="blog.php"> Blog</a>
                              </div>
                         </li>
                    </ul>
                    <div class="my-2 my-lg-0">
                         
                    </div>
               </div>
          </nav>
	</div>
     </header>