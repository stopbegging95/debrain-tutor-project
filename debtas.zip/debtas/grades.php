<div class="container-fluid col-12" id="banContainerFluid" >
  <div class="container col-12 d-none d-md-block" id="banContainer">
    <div class="banner col-12">
            <img src="images/stu7.png" />
    </div>
  </div>
  <div class="container col-12" id="resultContainer">
    <div class="row col-12">
      <h3> RESULT GRADING :: Points </h3>
      <div id="articleDiv" class="col-12">
                    
        <div class="col-xl-3 col-lg-3 col-md-4 col-sm-12 col-xs-12 d-none d-md-block" id="artImg">
          <img src="images/1.jpg" alt="ijmb image">
        </div>
          <div id="artText" class="col-xl-9 col-lg-9 col-md-8 col-sm-12 col-xs-12">
            <p>
            IJMB | JUPEB points are graded from A to F that is from 0 points to 5 points which are obtained from the combined score of the continues assessment ( C. A. ) which is 20% and the final examination score which is 80%.
            The continues assessment is conducted from time to time during the programme period to assess the understanding of every student at the end of every topic of the syllabus.
            During this IJMB programme period, intensive lectures are conducted which is guided by the IJMB syllabus and the syllabus of the IJMB programme covers up to 200 level syllabus of the university which must be taught for a minimum period of 9 months.
            Also during JUPEB programme period, intensive lectures are also conducted which is guided by the JUPEB syllabus and the syllabus of JUPEB programme also covers up to 200 level syllabus of the university which must be taught for a minimum period of 6 months.
            </p>
          </div>
          
      <!-- section for schoo fees goes here goes here -->
          <div id="accord" class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12">
            <h3>Point & Grades According To The Scores. </h3>

          <div class="row col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12 accordTable">

					<div class="accordion col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-10" id="accordionExample">
						<div class="card col-12">
						    <div class="card-header" id="headingOne">
						      <h2 class="mb-0">
						        <button class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                      IJMB & JUPEB POINT GRADES       (WITH     EXAMPLE).
						        </button>
						      </h2>
						    </div>

						    <div id="collapseOne" class="collapse" aria-labelledby="headingOne" data-parent="#accordionExample">
							    <div class="card-body col-xl-5 col-lg-5 col-sm-5 col-sm-12 col-xs-12">
                    <table class="table">
                      <thead>
                        <tr>
                          <th scope="col">GRADE</th>
                          <th scope="col"> SCORES </th>
                          <th scope="col"> POINT </th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <th scope="row">A</th>
                          <td class="colmid">70 - 100 </td>
                          <td> 5 </td>
                        </tr>
                        <tr>
                          <th scope="row">B</th>
                          <td class="colmid"> 60 - 69 </td>
                          <td> 4 </td>
                        </tr>
                        <tr>
                          <th scope="row"> C </th>
                          <td class="colmid"> 50 - 59	 </td>
                          <td> 3 </td>
                        </tr>
                        <tr>
                          <th scope="row">D</th>
                          <td class="colmid"> 45 - 49	 </td>
                          <td> 2 </td>
                        </tr>
                        <tr>
                          <th scope="row">E</th>
                          <td class="colmid"> 40 - 44 </td>
                          <td> 1 </td>
                        </tr>
                        <tr>
                          <th scope="row">F</th>
                          <td class="colmid"> 0 - 39 </td>
                          <td> 0 </td>
                        </tr>
                      </tbody>
                    </table>	
							    </div>
                  <!--  IJMB SCHOOL FEES SECTION ENDS HERE-->
                  <!-- JUPEB SCHOOL FEES SECTION GOES HERE -->
                  <div id="jupeb" class="card-body col-xl-5 col-lg-5 col-sm-5 col-sm-12 col-xs-12">
                  <table class="table">
                      <thead>
                        <tr>
                          <th scope="col">SUBJECT</th>
                          <th scope="col"> POINT </th>
                          <th scope="col"> GRADE </th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <th scope="row">CHEMISTRY</th>
                          <td class="colmid"> 5 </td>
                          <td> A </td>
                        </tr>
                        <tr>
                          <th scope="row">PHYSICS</th>
                          <td class="colmid"> 4 </td>
                          <td> B </td>
                        </tr>
                        <tr>
                          <th scope="row"> BIOLOGY </th>
                          <td class="colmid"> 3	 </td>
                          <td> C </td>
                        </tr>
                        <tr>
                          <th scope="row"> TOTAL POINT </th>
                          <td class="colmid"> 12 </td>
                          <td style="font-weight:bolder;"> +1 Additional = 13 </td>
                        </tr>
                      </tbody>
                    </table>	
							    </div>
                  <!-- JUEPB SCHOOL FEES SECTION ENDS HERE -->
						    </div>
						  </div>
					  </div>
			    </div> 
        </div>

        
<!-- section for sechool fees  ends here -->

      </div>
    </div>
  </div>
</div>