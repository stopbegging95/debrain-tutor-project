<?php
$amount = 5000;
//sanitize form input for users 
$sanitizer = filter_var_array($_POST, FILTER_SANITIZE_STRING);

// COLLECT USER'S INPUTS FROM THE FORM INTO REGULAR VARIABLE
$first_name = $sanitizer['first_name'];
$last_name = $sanitizer['last_name'];
$second_name = $sanitizer['second_name'];
$phone = $sanitizer['phone'];
$email = $sanitizer['email'];
// make sure all fields are filled in corrrectly 

if (empty($first_name) OR empty($second_name) OR empty($last_name) OR empty($phone) OR empty($email)) 
{

	header("Location: registration.php?error");

} else {
	session_start();
	$_SESSION['first_name'] = $first_name;
	$_SESSION['second_name'] = $second_name;
	$_SESSION['last_name'] = $last_name;
	$_SESSION['phone'] = $phone;
	$_SESSION['email'] = $email;
	$_SESSION['amount'] = $amount;
	//echo $first_name;
	//echo $last_name;
}

?>

<?php include("includes/header.php"); ?>

  <main>
  <div class="container-fluid col-12" id="banContainerFluid" >
  <div class="container col-12 d-none d-md-block" id="banContainer">
    <div class="banner col-12">
            <img src="images/stu7.png" />
    </div>
  </div>
  <div class="container col-12" id="paymentContainer">
    <div class="row col-12">
      <h3> REGISTRATION :: Payment </h3>
      <div id="articleDiv" class="col-12">
                    
        <!-- <div class="col-xl-3 col-lg-3 col-md-3 col-sm-12 col-xs-12" id="artImg">
          <img src="images/logo.png" alt="ijmb image">
        </div> -->
          <div id="artText" class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12">
                  <div class="login-box">
                    <h2> Make Payment</h2>
                    <h4> <?php echo $first_name. " " . $second_name. " " . $last_name . "<br/>" ?>  </h4>
                    
                    <h6> <?php echo "<strong style=\"color:white;\">" . "Email: " . $email . "</strong>" ; ?>  </h6>

                    <h4> <?php echo "<strong style=\"color:red;\">" . "Application Fee". " " . "N". $amount . "</strong>" ; ?>  </h4>
                    
                  <form>
                    <script src="https://js.paystack.co/v1/inline.js"></script>
                    <button type="button" onclick="payWithPaystack()"> Make Payment </button> 
                  </form>
                  
                  <script>
                    // const api = "pk_test_b8ac4ae06af1c4ef42b06805088473e67a1bdd91";
                    function payWithPaystack(){
                      // const api = "pk_live_22e5d1f5a290121b09037a60506ff4d3f11460f5";
                      const api = "pk_test_b8ac4ae06af1c4ef42b06805088473e67a1bdd91";
                      var handler = PaystackPop.setup({
                        key: api,
                        email: '<?php echo $email; ?>',
                        amount: '<?php echo $amount*100; ?>',
                        currency: "NGN",
                        ref: ''+Math.floor((Math.random() * 1000000000) + 1), // generates a pseudo-unique reference. Please replace with a reference you generated. Or remove the line entirely so our API will generate one for you
                        firstname: '<?php echo $first_name; ?>',
                        // secondname: '<//?php //echo $second_name; ?>',
                        lastname: '<?php echo $last_name; ?>',
                        // label: "Optional string that replaces customer email"
                        metadata: {
                          custom_fields: [
                              {
                                  display_name: "<?php echo $first_name; ?>",
                                  custom_name:  "<?php echo $second_name; ?>",
                                  variable_name: "<?php echo $last_name; ?>",
                                  value: "<?php echo $phone; ?>",
                              }
                          ]
                        },
                        callback: function(response){
                            // alert('success. transaction ref is ' + response.reference);
                            const referenced = response.reference;
                            window.location.href = "successful.php?successfullypaid="+referenced;
                        },
                        onClose: function(){
                            alert('window closed');
                        }
                      });
                      handler.openIframe();
                    }
                  </script>
                  </div>
          </div>
        
<!-- section for address ends here -->
      </div>
    </div>
  </div>
</div>
  </main>
<?php include("includes/footer.php"); ?>