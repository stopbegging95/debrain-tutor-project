<?php include("includes/header.php"); ?>
  <main>
      <?php include("centers.php"); ?> 
  </main>
<?php include("includes/footer.php"); ?>