<?php
if (!isset($_SERVER['HTTP_REFERER']))
   {
     header("Location: index.php");
    exit;
}

?>


<?php include("includes/header.php"); ?>
<?php include("includes/jupebapplication.php"); ?>
  <main>
  <div class="container-fluid col-12" id="banContainerFluid" >
  <div class="container col-12 d-none d-md-block" id="banContainer">
    <div class="banner col-12">
            <img src="images/stu7.png" />
    </div>
  </div>
  <div class="container col-12" id="applicationContainer">
    <div class="row col-12">
      <h3> APPLICATION FORM :: Data Collection </h3>
      <div id="articleDiv" class="col-12">
                    
        <!-- <div class="col-xl-3 col-lg-3 col-md-3 col-sm-12 col-xs-12" id="artImg">
          <img src="images/logo.png" alt="ijmb image">
        </div> -->
          <div id="artText" class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12">
          <form id="msform" class="form-control" role="form" action="<?= $_SERVER['PHP_SELF']; ?>" method="post" enctype="multipart/form-data" >
  <!-- progressbar -->
              <ul id="progressbar">
                <li class="active">Student Personal Info.</li>
                <li>PROGRAM APPLICATION</li>
                <li>Parent | Guardian Info.</li>
              </ul>
              <!-- fieldsets -->
              <fieldset class="col-12">
                <h2 class="fs-title">Personal Information</h2>
                <h3 class="fs-subtitle"></h3>
                <div class="success"> <?= $success ?? ''; ?> </div>
                
                <input type="text" name="first_name" class="form-control is-valid col-xl-3 col-lg-3" id="firstName" placeholder="Surname" value="<?= $first_name ?? '' ?>" required/> <span class="error"><?= $first_name_error ?? '' ?></span>
                
                <input type="text" name="second_name" class="form-control is-valid col-xl-3 col-lg-3 " id="secondName"placeholder="Your Name" value="<?= $second_name ?? '' ?>" required/> <span class="error"><?= $second_name_error ?? '' ?></span>

                <input type="text" name="middle_name" class="form-control is-valid col-xl-3 col-lg-3" id="middleName"placeholder="Other Name" value="<?= $middle_name ?? '' ?>" required/> <span class="error"><?= $middle_name_error ?? '' ?></span>
                
                <input type="date" name="date_of_birth" class="form-control is-valid col-xl-3 col-lg-3" id="dob" placeholder="" value="<?= $date_of_birth ?? '' ?>" required/> <span class="error"><?= $date_of_birth_error ?? '' ?></span>
                
                <select name="sex" id="gender" class="form-control col-xl-3 col-lg-3" value="<?= $sex ?? '' ?>" required>
                  <option value="male" selected> Male</option>
                  <option value="female"> Female</option>
                </select> <span class="error"><?= $sex_error ?? '' ?></span>

                <select name="state_of_origine" id="stateoforigine" class="form-control col-xl-3 col-lg-3" value="<?= $state_of_origin ?? '' ?>" required>
                                <option value="" selected>State of origin</option>
                                <option value="abia"> Abia</option>
                                <option value="adamawa">Adamawa</option>
                                <option value="akwaibom"> Akwa Ibom</option>
                                <option value="anambra"> Anambra</option>
                                <option value="bauchi"> Bauchi</option>
                                <option value="bayelsa"> Bayelsa</option>
                                <option value="benue"> Benue</option>
                                <option value="Borno"> Borno</option>
                                <option value="crossriver"> Cross River</option>
                                <option value="deltastate"> Delta Ebonyi</option>
                                <option value="edostate"> Edo State</option>
                                <option value="ekitistate"> Ekiti State</option>
                                <option value="enugustate"> Enugu State</option>
                                <option value="gombe"> Gombe</option>
                                <option value="imo"> Imo</option>
                                <option value="jigawa"> Jigawa</option>
                                <option value="kaduna"> Kaduna</option>
                                <option value="kano"> Kano</option>
                                <option value="katsina"> Katsina</option>
                                <option value="kebbi"> Kebbi</option>
                                <option value="kogi"> Kogi</option>
                                <option value="kwara"> Kwara</option>
                                <option value="lagos"> Lagos</option>
                                <option value="nasarawa"> Nasarawa</option>
                                <option value="niger"> Niger</option>
                                <option value="ogun"> Ogun</option>
                                <option value="ondo"> Ondo</option>
                                <option value="osun"> Osun</option>
                                <option value="oyo"> Oyo</option>
                                <option value="plateau"> Plateau</option>
                                <option value="rivers"> Rivers</option>
                                <option value="sokoto"> Sokoto</option>
                                <option value="taraba"> Taraba</option>
                                <option value="yobe"> Yobe</option>
                                <option value="zamfara"> Zamfara</option>
                                <option value="fct"> F.C.T. (Abuja)</option>
                            </select>
                            <span class="error"><?= $state_of_origine_error ?? '' ?></span>

                <input type="text" name="localgovarea" class="form-control is-valid col-xl-3 col-lg-3" id="localgovermentarea" placeholder=" Input Your Local Government Area" value="<?= $localgovarea ?? '' ?>" required/>
                <span class="error"><?= $localgovarea_error ?? '' ?></span>

                <input type="tel" name="mobile" class="form-control is-valid col-xl-3 col-lg-3" id="mobile"
                placeholder=" Valid Phone Number" value="<?= $mobile ?? '' ?>" required/>
                <span class="error"><?= $mobile_error ?? '' ?></span>

                <input type="email" name="email" class="form-control is-valid col-xl-3 col-lg-3" id="Email" placeholder="Email Address" value="<?= $email ?? '' ?>" required/>
                <span class="error"><?= $email_error ?? '' ?></span>

                <input type="text" name="home_address" class="form-control is-valid col-xl-11 col-lg-11" id="Homeaddress" placeholder="Contact Home Address" value="<?= $home_address ?? '' ?>" required/>
                <span class="error"><?= $home_address_error ?? '' ?></span>

                <input type="button" name="next" class="next action-button col-xl-6 col-lg-6" value="Next" />

              </fieldset>
              <fieldset>
                <h2 class="fs-title"> Program Application Form</h2>
                <h3 class="fs-subtitle"></h3>

                <select name="select_prog" id="Programme" class="form-control col-xl-3 col-lg-3" value="<?= $select_prog ?? '' ?>" required>
                    <option value="jupeb" selected> jupeb</option>
                </select>
                <span class="error"><?= $select_prog_error ?? '' ?></span>

                <select name="department" id="seldepart" class="form-control col-xl-3 col-lg-3"
                value="<?= $department ?? '' ?>" required> 
                  <option value="" selected>Select Department</option>
                  <option value="art"> Art</option>
                  <option value="commercial"> Commercial</option>
                  <option value="science"> Science</option>
                </select> <span class="error"><?= $department_error ?? '' ?></span>

                <select name="course" id="selcourse" class="form-control col-xl-3 col-lg-3" value="<?= $course ?? '' ?>" required>
                <option value="" selected>Choose Course</option>
                <option value="accounting"> Accounting</option>
                <option value="adultEducation"> Adult Education</option>
                <option value="aeronatic"> Aeronatic Engineering</option>
                <option value="agriculturalScienceEducation"> Agricultural Science & Education</option>
                <option value="agriculturalScience"> Agricultural Science</option>
                <option value="agriculturalBiosytemEngr"> Agricultural and Biosystem Engineering
                </option>
                <option value="analtomy"> Analtomy</option>
                <option value="appliedGeophysics"> Applied Geophysics</option>
                <option value="arabicStudies"> Arabic Studies</option>
                <option value="architecture"> Architecture</option>
                <option value="bioChemistry"> Bio-Chemistry</option>
                <option value="biology"> Biology</option>
                <option value="biomedicalEngr"> Biomedical Engineering</option>
                <option value="businessAdmin"> Business Administration</option>
                <option value="bussinessEdu"> Business Education</option>
                <option value="buildingTechEdu"> Building Tech. Edu.</option>
                <option value="chemicalEngr"> Chemical Engineering</option>
                <option value="chemistry"> Chemistry</option>
                <option value="christianStudies"> Christian Studies</option>
                <option value="civilEngr"> Civil Engineering</option>
                <option value="commonIslamicLaw"> Common & Islamic Law</option>
                <option value="commonLow"> Common Law</option>
                <option value="computerEngr"> Computer Engineering</option>
                <option value="computerScience"> Computer Science</option>
                <option value="counsellorEducation"> Counsellor Education</option>
                <option value="criminologySecurityStudies"> Criminology & Secyrity Sudies</option>
                <option value="cyberSecurity"> Cyber Security</option>
                <option value="doctorofPharmacy"> Doctor of Pharmacy</option>
                <option value="economics"> Economics</option>
                <option value="educationArabic"> Education & Arabic</option>
                <option value="educationBiology"> Education & Biology</option>
                <option value="educationChemistry"> Education & Chemistry</option>
                <option value="educationChristianReligionStudies"> Education & Christian Religion
                    Studies
                </option>
                <option value="educationComputerScience"> Education & Computer Science</option>
                <option value="educationEconomics"> Education & Economics</option>
                <option value="educationEnglishLanguage"> Education & English Language</option>
                <option value="educationFrench"> Education & French</option>
                <option value="educationGeography"> Education & Geography</option>
                <option value="educationHistory"> Education & History</option>
                <option value="educationIslamicStudies"> Education & Islamic Studies</option>
                <option value="educationMathematics"> Education & Mathematics</option>
                <option value="educationPhysics"> Education & Physics</option>
                <option value="educationSocialStudies"> Education & Social Studies</option>
                <option value="educationYoruba"> Education & Yoruba</option>
                <option value="educationalManagement"> Educationl Management</option>
                <option value="educationalTechnologyIntro"> Educational Tech. / Introductory
                    Tech.
                </option>
                <option value="electricalElectronicsEngr"> Electrical / Electronic Engineering</option>
                <option value="electricalElectronicsTech"> Electrical / Electronic Tech. Edu.</option>
                <option value="englishLanguage"> English Language</option>
                <option value="estateManagement"> Estate Management</option>
                <option value="finance"> Finance</option>
                <option value="fisheriesAndAquaculture"> Fisheries and Aquaculture</option>
                <option value="foodEngr"> Food Engineering</option>
                <option value="foodScience"> Food Science</option>
                <option value="forestry"> Forestry and Wild Life Management</option>
                <option value="french"> French</option>
                <option value="geographyEnvironMang"> Geography and Environmental management</option>
                <option value="geology"> Geology</option>
                <option value="hausa"> Hausa</option>
                <option value="healthEducation"> Health Education</option>
                <option value="historyInterStudies"> History and International Studies</option>
                <option value="homeEconomics"> Home Economics</option>
                <option value="humankinetics"> Human Kinetics</option>
                <option value="igbo"> Igbo</option>
                <option value="industrialChem"> Industrial Chemistry</option>
                <option value="informationTech"> Information Technology</option>
                <option value="informationSys"> Information System</option>
                <option value="industrialRelationPer"> Industrial Relation and Personal Management
                </option>
                <option value="informationComScience"> Information and Communication Science</option>
                <option value="islamicStudies"> Islamic Studies</option>
                <option value="law"> Law </option>
                <option value="libraryInfoScience"> Library and Information Science</option>
                <option value="linguistics"> Linguistics</option>
                <option value="marketting"> Marketting</option>
                <option value="massCom"> Mass Communication</option>
                <option value="mathematics"> Mathematics</option>
                <option value="medicalEngr"> Mechanical Engineering</option>
                <option value="medecineSurgry"> Medecine and Surgery</option>
                <option value="metallogicalMaterialEngr"> Metallogical and Material Engineering</option>
                <option value="metalWorkTechEdu"> Metal Work Tecnology Education</option>
                <option value="microBiology"> Micro Biology</option>
                <option value="nursingNursingScience"> Nursing / Nursing Science</option>
                <option value="optometry"> Optometry</option>
                <option value="performaingArt"> Performing Art</option>
                <option value="pharmacy"> Pharmacy</option>
                <option value="physics"> Physics</option>
                <option value="physiology"> Physiology</option>
                <option value="physiotheraphy"> Physiotheraphy</option>
                <option value="plantBiology"> Plant Biology</option>
                <option value="politicalScience"> Political Science</option>
                <option value="primaryEducationStudies"> Primary Education Studies</option>
                <option value="psychology"> Psychology</option>
                <option value="publicAdmin"> Public Administration</option>
                <option value="quantitySurveying"> Quantity Survaying</option>
                <option value="scienceLaboratoryTech"> Science Laboratory Technology</option>
                <option value="sociology"> Sociology</option>
                <option value="softwareEngr"> Software Engineering</option>
                <option value="statistics"> Statistics</option>
                <option value="surveyingGeoInfor"> Surveying Geo-Informatics</option>
                <option value="technicalEdu"> Technical Education</option>
                <option value="technologyEdu"> Technology Education</option>
                <option value="telecommunicationScience"> Telecommunication Science</option>
                <option value="telecommunicationEngr"> Telecommunication Engineering</option>
                <option value="urbanRegionalPlanning"> Urban and Regional Planning</option>
                <option value="veterinaryMed"> Veterinary Medcine</option>
                <option value="waterResourcesEnvironEngr"> Water Resources and Envirn. Engr.</option>
                <option value="yoruba"> Yoruba</option>
                <option value="zoology"> Zoology</option>
            </select>
            <span class="error"><?= $course_error ?? '' ?></span>

            <select name="olevel_res" id="selolevel" class="form-control col-xl-3 col-lg-3" value="<?= $olevel_res ?? '' ?>" required>
              <option value="" selected>Select O'Level</option>
              <option value="awaiting"> Awaiting</option>
              <option value="waec"> WAEC</option>
              <option value="waecgce"> WAEC / GCE</option>
              <option value="gce"> GCE</option>
              <option value="neco"> NECO</option>
              <option value="necogce"> NECO / NECO GCE</option>
              <option value="nabteb"> NABTEB</option>
            </select>
            <span class="error"><?= $olevel_res_error ?? '' ?></span>

            <select name="olevel_res" id="selolevel" class="form-control col-xl-3 col-lg-3 disabled" value="<?= $olevel_res ?? '' ?>" disabled>
              <option value="" selected></option>
              <option value="awaiting"> Awaiting</option>
              <option value="waec"> WAEC</option>
              <option value="waecgce"> WAEC / GCE</option>
              <option value="gce"> GCE</option>
              <option value="neco"> NECO</option>
              <option value="necogce"> NECO / NECO GCE</option>
              <option value="nabteb"> NABTEB</option>
            </select>
            <span class="error"><?= $olevel_res_error ?? '' ?></span>

            <select name="olevel_res" id="selolevel" class="form-control col-xl-3 col-lg-3 " value="<?= $olevel_res ?? '' ?>" disabled>
              <option value="" selected></option>
              <option value="awaiting"> Awaiting</option>
              <option value="waec"> WAEC</option>
              <option value="waecgce"> WAEC / GCE</option>
              <option value="gce"> GCE</option>
              <option value="neco"> NECO</option>
              <option value="necogce"> NECO / NECO GCE</option>
              <option value="nabteb"> NABTEB</option>
            </select>
            <span class="error"><?= $olevel_res_error ?? '' ?></span>

                <input type="button" name="previous" class="previous action-button col-xl-4 col-lg-4" value="Previous" />
                <input style="float:right !important;" type="button" name="next" class=" next action-button col-xl-4 col-lg-4" value="Next" />

              </fieldset>
              <fieldset>
                <h2 class="fs-title">Parent | Guardian Information</h2>
                <h3 class="fs-subtitle"></h3>
                
                <input type="text" name="guardian_first_name" class="form-control is-valid col-xl-3 col-lg-3" id="firstName" placeholder="Guardian Surname " value="<?= $guardian_first_name ?? '' ?>" required/>
                <span class="error"><?= $guardian_first_name_error ?? '' ?></span>

                <input type="text" name="guardian_second_name" class="form-control is-valid col-xl-3 col-lg-3" id="secondName"placeholder=" Guardian Name" value="<?= $guardian_second_name ?? '' ?>" required/>
                <span class="error"><?= $guardian_second_name_error ?? '' ?></span>

                <input type="text" name="guardian_middle_name" class="form-control is-valid col-xl-3 col-lg-3" id="middleName" placeholder="Guardian Other Name" value="<?= $guardian_middle_name ?? '' ?>"/>
                <span class="error"><?= $guardian_middle_name_error ?? '' ?></span>

                <input type="date" name="guardian_date_of_birth" class="form-control is-valid col-xl-3 col-lg-3" id="dateofbirth" placeholder="" value="<?= $guardian_date_of_birth ?? '' ?>"/>
                <span class="error"><?= $guardian_date_of_birth_error ?? '' ?></span>
                
                <select name="guardian_sex" id="gender" class="form-control col-xl-3 col-lg-3" value="<?= $guardian_sex ?? '' ?>">
                    <option value="male" selected> Male</option>
                    <option value="female"> Female</option>
                </select>
                <span class="error"><?= $guardian_sex_error ?? '' ?></span>

                <select name="guardian_state_of_origine" id="stateoforigine" class="form-control col-xl-3 col-lg-3" value="<?= $guardian_state_of_origine ?? '' ?>">
                  <option value="" selected>Choose...</option>
                  <option value="abia"> Abia</option>
                  <option value="adamawa">Adamawa</option>
                  <option value="akwaibom"> Akwa Ibom</option>
                  <option value="anambra"> Anambra</option>
                  <option value="bauchi"> Bauchi</option>
                  <option value="bayelsa"> Bayelsa</option>
                  <option value="benue"> Benue</option>
                  <option value="Borno"> Borno</option>
                  <option value="crossriver"> Cross River</option>
                  <option value="deltastate"> Delta Ebonyi</option>
                  <option value="edostate"> Edo State</option>
                  <option value="ekitistate"> Ekiti State</option>
                  <option value="enugustate"> Enugu State</option>
                  <option value="gombe"> Gombe</option>
                  <option value="imo"> Imo</option>
                  <option value="jigawa"> Jigawa</option>
                  <option value="kaduna"> Kaduna</option>
                  <option value="kano"> Kano</option>
                  <option value="katsina"> Katsina</option>
                  <option value="kebbi"> Kebbi</option>
                  <option value="kogi"> Kogi</option>
                  <option value="kwara"> Kwara</option>
                  <option value="lagos"> Lagos</option>
                  <option value="nasarawa"> Nasarawa</option>
                  <option value="niger"> Niger</option>
                  <option value="ogun"> Ogun</option>
                  <option value="ondo"> Ondo</option>
                  <option value="osun"> Osun</option>
                  <option value="oyo"> Oyo</option>
                  <option value="plateau"> Plateau</option>
                  <option value="rivers"> Rivers</option>
                  <option value="sokoto"> Sokoto</option>
                  <option value="taraba"> Taraba</option>
                  <option value="yobe"> Yobe</option>
                  <option value="zamfara"> Zamfara</option>
                  <option value="fct"> F.C.T. (Abuja)</option>
              </select>
              <span class="error"><?= $guardian_state_of_origine_error ?? '' ?></span>

              <input type="text" name="guardian_localgovarea" class="form-control is-valid col-xl-3 col-lg-3"
              id="localgovermentarea" placeholder=" Guardian Local Government Area"
              value="<?= $guardian_localgovarea ?? '' ?>"/>
              <span class="error"><?= $guardian_localgovarea_error ?? '' ?></span>

              <input type="tel" name="guardian_mobile" class="form-control is-valid col-xl-3 col-lg-3" id="mobile" placeholder="Valid Phone Number" value="<?= $guardian_mobile ?? '' ?>"/>
              <span class="error"><?= $guardian_mobile_error ?? '' ?></span>

              <input type="email" name="guardian_email" class="form-control is-valid col-xl-3 col-lg-3" id="Email"
              placeholder="Valid Email Address" value="<?= $guardian_email ?? '' ?>"/>
              <span class="error"><?= $guardian_email_error ?? '' ?></span>

              <input type="text" name="guardian_home_address" class="form-control is-valid col-xl-11 col-lg-11"
              id="Homeaddress" placeholder="Contact Home Address" 
              value="<?= $guardian_home_address ?? '' ?>"/>
              <span class="error"><?= $guardian_home_address_error ?? '' ?></span>

              <input type="button" name="previous" class="previous action-button col-xl-4 col-lg-4" value="Previous" />
<!--               
                <input href="#" style="float:right !important;" type="submit" name="submit" class="submit action-button col-xl-4 col-lg-4" value="Submit" /> -->

                <button style="float:right !important;"href="#" class="action-button btn btn-block col-xl-4 col-lg-4" name="submit" value="submit" type="submit">Submit
                        </button>

                
              </fieldset>

            </form>
          </div>
          
      
      <!-- section for address ends here -->
            </div>
          </div>
        </div>
      </div>
  </main>
<?php include("includes/footer.php"); ?>