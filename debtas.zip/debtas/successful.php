<?php

 session_start();
 if (!$_GET['successfullypaid']) 
	{
 	header("Location: index.php");
 	exit();
 } else {
 	$reference = $_GET['successfullypaid'];
 }
$first_name = $_SESSION['first_name'];
$second_name = $_SESSION['second_name'];
$last_name = $_SESSION['last_name'];
$phone = $_SESSION['phone'];
$email = $_SESSION['email'];
$amount = $_SESSION['amount'];

?> 


<?php include("includes/header.php"); ?>
  <main>
  <div class="container-fluid col-12" id="banContainerFluid" >
  <div class="container col-12 d-none d-md-block" id="banContainer">
    <div class="banner col-12">
            <img src="images/stu7.png" />
    </div>
  </div>
  <div class="container col-12" id="successfulContainer">
    <div class="row col-12">
      <h3> SELECT PROGRAM :: For Registration </h3>
      <div id="articleDiv" class="col-12">
                    
        <!-- <div class="col-xl-3 col-lg-3 col-md-3 col-sm-12 col-xs-12" id="artImg">
          <img src="images/logo.png" alt="ijmb image">
        </div> -->
          <div id="artText" class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12">
            <p>
              <article>
              Your payment has been made succesfully, Check your E-mail for copy of your payment receipt. to complete your registration please click on  
						<!-- <a href="index.php"> <i class="fa fa-window-close"></i> Close Application </a> -->
						<a href= "applicationform.php" > <i class="fa fa-caret-right"></i> Continue Application </a> 
								<!-- <br> <br>
								<strong> NOTE:  </strong> After payment applicant should proceed to the application form to complete his or her registration, applicant most carefully fill the online application form to avoid error in the regisration thanks. -->
              </article>
            </p>
          </div>
          
      <!-- section for art goes here -->
              <div id="accord" class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12">
              <h4> Payment Receipt </h4>

                  <table class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12" >
                      
                      <thead>
                        <tr>
                          <th>FIRST NAME </th>
                          <th> SECOND NAME </th>
                          <th> LAST NAME </th>
                          <th>PHONE NUMBER </th>
                        <th>E-MAIL </th>
                        <th>AMOUNT PAID </th>
                        <th>REFERENCE </th>
                        </tr>
                      </thead>

                      <tbody id="tbodylecture">
                        <tr>
                          <th> <?php echo $first_name; ?>  </th>
                          <th> <?php echo $second_name; ?>  </th>
                          <th> <?php echo $last_name; ?>  </th>
                          <th> <?php echo $phone; ?>  </th>
                          <th> <?php echo $email; ?>  </th>
                          <th> <?php echo "NGN ".$amount; ?>  </th>
                          <th> <?php echo $reference; ?>  </th>
                        </tr>
                      </tbody>

                  </table>
             
              </div>
      <!-- section for address ends here -->
            </div>
          </div>
        </div>
      </div>
  </main>
<?php include("includes/footer.php"); ?>