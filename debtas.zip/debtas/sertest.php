
       <!-- Note: other services and testimonies hmtl code started here here  -->
<div class="container-fluid" id="serviceTestimony" >
 	<div class="container col-xl-12 col-lg-12 col-sm-12 col-xs-12">
        <div class="sertes col-xl-4 col-lg-4 col-md-4 col-sm-12 col-xs-12" id="otherServices">
                  <div id="otherServicesHead">
                    <h3 class="h3"> Other Services <h3>
                  </div>

                  <ul class="" id="serList">
                    <li> <span class="fa fa-hand-o-right"> </span> Academy Consultancy </li>
 							      <li> <span class="fa fa-hand-o-right"> </span> Admission Consultancy </li>
 							      <li> <span class="fa fa-hand-o-right"> </span> University Admission Process </li>
 							      <li> <span class="fa fa-hand-o-right"> </span> Education Counselling </li>
 							      <li> <span class="fa fa-hand-o-right"> </span> Home Tutor </li>
                  </ul>
        </div>
              
        <div class="sertes col-xl-8 col-lg-8 col-md-8 col-sm-12 col-xs-12" id="ourTestimonies">
                  <div id="ourTestimoniesHead">
                    <h3 class="h3"> Our Testimonies <h3>
                  </div>

          <div id="ourTestimoniesbanner"> 
                    <!-- <img src="images/background2.jpg" /> -->
            <div id="carouselExampleCaptions1" class="carousel slide" data-ride="carousel" style="background-color:green;">
                      <!-- <ol class="carousel-indicators">
                        <li data-target="#carouselExampleCaptions1" data-slide-to="0" class="active"></li>
                        <li data-target="#carouselExampleCaptions1" data-slide-to="1"></li>
                        <li data-target="#carouselExampleCaptions1" data-slide-to="2"></li>
                        <li data-target="#carouselExampleCaptions1" data-slide-to="3"></li>
                      </ol> -->
                      <div class="carousel-inner" >
                        <div class=" carousel-item active">
                          <img src="images/background2.jpg" class="d-block w-100" alt="...">
                          <div class="carousel-caption col-12">
                            
                            <p>"Glory be to God almighty who had made it possible for me to be able, to bring together all that i had learned during the perioud of my 9months course at DEBTAS Advanced Studies Educational Services, the one who made the kownlege work out for me and all ended in praise thanks to the De-brain-tutor thanks to IJMB BOARD"
                            </p>
                          
                            <h5>ODUYOMI ABOSEDE</h5>
                            
                          </div>
                        </div>
                        <div class="carousel-item">
                          <img src="images/background2.jpg" class="d-block w-100" alt="...">
                          <div class="carousel-caption">
                             <p>"It a grate honour to be among the graduates of DE-BRAIN-TUTOR Advanced Studies Educational Services. and i pray for more success in my university level, thank you my memorable director, thanks you my memorable teachers, thank you DEBTAS Hope to see you all again. With IJMB your admission is guaranteed"
                            </p>
                          
                            <h5>AJIBOYE ADEBIMPE</h5>
                          </div>
                        </div>
                        <div class="carousel-item">
                          <img src="images/background2.jpg" class="d-block w-100" alt="...">
                          <div class="carousel-caption">
                             <p>"my grate gratitude goes to DE-BRAIN-TUTOR Advanced Studies Educational Services.. it is a grate opportunity to be among the succesful one who have passed through this institution. i pray for more success ahead. God bless DEBTAS Advanced Studies Educational Services. IJMB is the key to easy admission. Thanks"
                            </p>
                          
                            <h5>ADENIYI ROKEEB</h5>
                          </div>
                        </div>
                        <div class="carousel-item">
                          <img src="images/background2.jpg" class="d-block w-100" alt="...">
                          <div class="carousel-caption ">
                             <p>"It a grate honour to be among the graduates of DEBTAS Advanced Studies Educational Services. and i pray for more success in my university level, thank you my memorable director, thanks you my memorable teachers, thank you DE-BRAIN-TUTOR. Hope to see you all again. With IJMB your admission is guaranteed"
                            </p>
                          
                            <h5>FATOGUN OLAYINKA</h5>
                          </div>
                        </div> 
                     
                        <a class="carousel-control-prev" href="#carouselExampleCaptions1" role="button" data-slide="prev" id="leftIndicator">
                          <span class="fa fa-arrow-circle-left" aria-hidden="true"></span>
                          <span class="sr-only">Previous</span>
                        </a>
                        <a class="carousel-control-next" href="#carouselExampleCaptions1" role="button" data-slide="next">
                          <span class="fa fa-arrow-circle-right" aria-hidden="true"></span>
                          <span class="sr-only">Next</span>
                        </a>
                      </div>
              </div>
            </div>
          </div>
        </div>
  </div>
</div>
              <!-- Note: the banner carousel hmtl code ends here here  -->
      