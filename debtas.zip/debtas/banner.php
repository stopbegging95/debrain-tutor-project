  <!-- Note: the banner carousel hmtl code started here here  -->

  <div id="banner" class="col-12"> 
            <!-- <img src="images/background2.jpg" /> -->
            <div id="carouselExampleCaptions" class="carousel slide" data-ride="carousel" style="background-color:green;">
              <!-- <ol class="carousel-indicators">
                <li data-target="#carouselExampleCaptions" data-slide-to="0" class="active"></li>
                <li data-target="#carouselExampleCaptions" data-slide-to="1"></li>
                <li data-target="#carouselExampleCaptions" data-slide-to="2"></li>
              </ol> -->
              <div class="carousel-inner" >
                <div class=" carousel-item active">
                  <img src="images/background2.jpg" class="d-block w-100" alt="...">
                  <div class="carousel-caption col-12">
                    <h5>WEL. TO DE-BRAIN-TUTOR</h5>
                    <p>ADVANCED STUDIES EDUCATIONAL CONSULT.</p>
                   
                  </div>
                </div>
                <div class="carousel-item">
                  <img src="images/background2.jpg" class="d-block w-100" alt="...">
                  <div class="carousel-caption">
                    <h5>IJMB & JUPEB 2021/2022</h5>
                    <p>Application Form Is Now Online </p>
                    <a href="onlineregistration.php"> Apply Now</a> 
                  </div>
                </div>
                <div class="carousel-item">
                  <img src="images/background2.jpg" class="d-block w-100" alt="...">
                  <div class="carousel-caption">
                    <h5>INT'L EXAMINATIONS </h5>
                    <p> IELTS TOEFL SAT GRE GMATHS. </p>
                    <a href="onlineregistration.php"> Apply Now</a> 
                  </div>
                </div>
              </div>
              <a class="carousel-control-prev" href="#carouselExampleCaptions" role="button" data-slide="prev" id="leftIndicator">
                <span class="fa fa-arrow-circle-left" aria-hidden="true"></span>
                <span class="sr-only">Previous</span>
              </a>
              <a class="carousel-control-next" href="#carouselExampleCaptions" role="button" data-slide="next">
                <span class="fa fa-arrow-circle-right" aria-hidden="true"></span>
                <span class="sr-only">Next</span>
              </a>
            </div>
        </div>
      <!-- Note: the banner carousel hmtl code ends here here  -->