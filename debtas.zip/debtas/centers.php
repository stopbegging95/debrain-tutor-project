<div class="container-fluid col-12" id="banContainerFluid" >
  <div class="container col-12 d-none d-md-block" id="banContainer">
    <div class="banner col-12">
            <img src="images/stu7.png" />
    </div>
  </div>
  <div class="container col-12" id="resultContainer">
    <div class="row col-12">
    <h3> OUR LECTURE CENTERS :: Locations</h3>
      <div id="articleDiv" class="col-12">
                    
        <div class="col-xl-3 col-lg-3 col-md-4 col-sm-12 col-xs-12 d-none d-md-block" id="artImg">
          <img src="images/1.jpg" alt="ijmb image">
        </div>
          <div id="artText" class="col-xl-9 col-lg-9 col-md-8 col-sm-12 col-xs-12">
            <p>
            DE-BRAIN-TUTOR ADVANCED STUDIES EDUCATIONAL SERVICES </strong> has been located at seven (7) different states accross the nation which are located at <strong> KWARA LAGOS, OYO, ABUJA, IMO, DELTA AND OGUN STATE. </strong> with a conducive lecture center, for student to recieve prominent lecture during their course of study.
            </p>
          </div>
          
          <!-- section for art goes here -->
          <div id="accord" class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-10">
            <h3> Locations</h3>

          <div class="row col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-10 accordTable">

					<div class="accordion col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-10" id="accordionExample">
						<div class="card col-12">
						    <div class="card-header" id="headingOne">
						      <h2 class="mb-0">
						        <button class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
						          List Of Our Available Centers
						        </button>
						      </h2>
						    </div>

						    <div id="collapseOne" class="collapse" aria-labelledby="headingOne" data-parent="#accordionExample">
							    <div class="card-body col-12">
                    <table class="table">
                      <thead>
                        <tr>
                          <th scope="col">S/N</th>
                          <th scope="col"> STATE LOCATED </th>
                          <th scope="col"> ADDRESS OF LOCATION </th>
                        </tr>
                      </thead>
                      <tbody id="tbodyyart">
                        <tr>
                          <th scope="row">1</th>
                          <td class="colmid">Lagos State (IJAIYE) </td>
                          <td> Km 696 Lagos Abeokuta Express Road, Opposite Ojokoro Micro Finance Bank, Ijaiye, Lagos. </td>
                        </tr>
                        <tr>
                          <th scope="row">2</th>
                          <td class="colmid"> Lagos State (Ikorodu) </td>
                          <td> 23 Mulikat Musediku Street, behind Zenith Bank, Jobi Hospital Road, Benson Bus-Stop, Ikorodu, Lagos. </td>
                        </tr>
                        <tr>
                          <th scope="row"> 3 </th>
                          <td class="colmid"> Kwara State </td>
                          <td> 9, Kulende Before Harmony Estate Sango Ilorin, Kwara State. </td>
                        </tr>
                        <tr>
                          <th scope="row">4</th>
                          <td class="colmid">Abuja FCT </td>
                          <td> No 65, 1Q2 Road fha, CBN Quaters, by new bennyrose, opposite amac mkt gate lugbe abuja. </td>
                        </tr>
                        <tr>
                          <th scope="row">5</th>
                          <td class="colmid"> Oyo State </td>
                          <td> Km 148, Lagos Ibadan Express Road, Opposite, Islim Filling Station, Academy, Bolueaji, Oyo State. </td>
                        </tr>
                        <tr>
                          <th scope="row"> 6 </th>
                          <td class="colmid"> Ogun State </td>
                          <td> 6 Onasanya Street Arigbawonwo Mowe Ogun State. </td>
                        </tr>
                        <tr>
                          <th scope="row"> 7 </th>
                          <td class="colmid"> Rivers State (P.H) </td>
                          <td> 15, East Road, Alh Estate, Behind Army Barrack Rumuokoro, Porth-Harcourt, Rivers State. </td>
                        </tr>
                        <tr>
                          <th scope="row"> 8 </th>
                          <td class="colmid"> Delta State </td>
                          <td> 115, Okeimute Estate Along Ehwere Road, and After Connerstop Junction Agbarho, Warri, Delta State. </td>
                        </tr>
                      </tbody>
                    </table>	

							    </div>
						    </div>
						  </div>
					  </div>
			    </div> 
        </div>
<!-- section for art ends here -->

      </div>
    </div>
  </div>
</div>