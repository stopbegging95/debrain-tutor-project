<div class="container-fluid col-12" id="banContainerFluid" >
    <div class="container col-12 d-none d-md-block" id="banContainer">
            <div class="banner col-12">
                <img src="images/stu7.png" />
            </div>
    </div>
    <div class="container col-12" id="artContainer">
            <div class="row col-12">
                <h3> ABOUT US :: Our Team</h3>
                <div id="articleDiv" class="col-12">
                    
                    <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-xs-12 d-none d-md-block" id="artImg">
                      <img src="images/logo.png" alt="articleimage">
                    </div>

                    <div id="artText" class="col-xl-8 col-lg-8 col-md-8 col-sm-12 col-xs-12">
                      
                      <p>
                      DE-BRAIN-TUTOR ADVANCED STUDIES EDUCATIONAL SERVICES is establish to solve solutions on academics, for both student in the Secondary Secondary School, and (S.S.C.E.) graduate looking forward to gain admission in to any university of their choice among Nigieria University.
                      </p>

                      <h3> Our Mission</h3>
                      
                      <p>
                      DE-BRAIN-TUTOR ADVANCED STUDIES EDUCATIONAL SERVICES is establish to solve solutions on academics, for both student in the Secondary Secondary School, and (S.S.C.E.) graduate looking forward to gain admission in to any university of their choice among Nigieria University.
                      </p>

                    </div>

                    <!-- <div id="artText2" class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12">

                    <h3> Our Mission</h3>
                      
                      <p>
                      DE-BRAIN-TUTOR ADVANCED STUDIES EDUCATIONAL SERVICES is establish to solve solutions on academics, for both student in the Secondary Secondary School, and (S.S.C.E.) graduate looking forward to gain admission in to any university of their choice among Nigieria University.
                      </p>

                    </div> -->

                </div>
            </div>

    </div>

</div>