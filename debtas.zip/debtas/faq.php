<?php include("includes/header.php"); ?>
  <main>
      <div class="container-fluid col-12" id="banContainerFluid" >
      <div class="container col-12 d-none d-md-block" id="banContainer">
        <div class="banner col-12">
                <img src="images/stu7.png" />
        </div>
      </div>
      <div class="container col-12" id="faqContainer">
        <div class="row col-12">
          <h3> FAQ :: Frequently Asked Question</h3>
          <div id="articleDiv" class="col-12">
                        
            <div class="col-xl-2 col-lg-2 col-md-2 col-sm-12 col-xs-12 d-none d-md-block" id="artImg">
              <img src="images/ijmb.png" alt="ijmb image">
            </div>
            <div class="col-xl-2 col-lg-2 col-md-2 col-sm-12 col-xs-12 d-none d-md-block" id="artImg">
                <img src="images/jupeblogo.png" alt="jupeb image">
            </div>
              <div id="artText" class="col-xl-8 col-lg-8 col-md-8 col-sm-12 col-xs-12">
                <p>
                Our Frequently Asked Questions page has been created for solving problem of student who needs definite and accurate answer for their unclear thought. both on education counselling and admission processing.
                </p>
              </div>
              
          <!-- section for art goes here -->
              <div id="accord" class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <h3> UNI THAT ACCEPT IJMB | JUPEB </h3>

              <div class="row col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12 accordTable">

              <div class="accordion col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-10" id="accordionExample">
                <div class="card col-12">
                    <div class="card-header" id="headingOne">
                      <h2 class="mb-0">
                        <button class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                          IS IJMB | JUPEB ACCEPTED IN ALL NIGERIA UNI?
                        </button>
                      </h2>
                    </div>

                    <div id="collapseOne" class="collapse" aria-labelledby="headingOne" data-parent="#accordionExample">
                      <div class="card-body">
                        <P>
                            IJMB is accpeted in all Nigeria school except UNIVERSITY OF LAGOS. being is the founder of JUPEB Examination which works in education industry as IJMB, so as to promote JUPEB Examination in her own university. also NOTE that AMADU BELLO UNIVERSITY of ZARIA, has been the institute behind the establishment of IJMB and which her own institute also will not accept JUPEB. but for all other universities accross Nigeria both IJMB and JUPEB are accepted for Direct Admission into 200L of any university of your choice.
                        </P>	

                      </div>
                    </div>
                  </div>
                </div>
              </div> 
            </div>
    <!-- section for art ends here -->

    <!-- section for science goes here -->

    <div id="accord" class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <h3> DID I NEED JAMB?</h3>

              <div class="row col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12 accordTable">

              <div class="accordion col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-10" id="accordionExample2">
                <div class="card col-12">
                    <div class="card-header" id="headingTwo">
                      <h2 class="mb-0">
                        <button class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="true" aria-controls="collapseTwo">
                          DID I NEED JAMB OF IJMB OR JUPEB
                        </button>
                      </h2>
                    </div>

                    <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionExample2">
                      <div class="card-body">
                        <p>
                        capital NO. you don't need jamb for IJMB or JUPEB all you need is to obtain a D.E form when it available on JAMB website for you to be able to choose university of your choice.
                        </p>
                    
                      </div>
                    </div>
                  </div>
                </div>
              </div> 
            </div>
    <!-- section for science ends here -->
    <!-- section for commercial goes here -->

    <div id="accord" class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <h3> DIRECT 200L ADMISSION</h3>

              <div class="row col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12 accordTable" id="accordionExample3">

              <div class="accordion col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-10" id="accordionExample3">
                <div class="card col-12">
                    <div class="card-header" id="headingThree">
                      <h2 class="mb-0">
                        <button class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapseThree" aria-expanded="true" aria-controls="collapseThree">
                         DO YOU OFFER DIRECT ADMISSION INTO NIGERIA UNI.
                        </button>
                      </h2>
                    </div>

                    <div id="collapseThree" class="collapse" aria-labelledby="headingThree" data-parent="#accordionExample3">
                      <div class="card-body">
                          <P>
                          capital YES. that has been the reason why DE-BRAIN-TUTOR ADVANCED STUDIES EDUCATIONAL SERVICES have come to you rescue with the 80% accurance of excellect result in IJMB | JUPEB that will sit you down in 200Level in any university of your choice.
                          </P>
                      </div>
                    </div>
                  </div>
                </div>
              </div> 
            </div>
    <!-- section for commercial ends here -->
          </div>
        </div>
      </div>
    </div>
  </main>
<?php include("includes/footer.php"); ?>