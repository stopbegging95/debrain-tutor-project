<select name="title" id="seltitle" class="form-control col-xl-2 col-lg-2" value="<?= $title ?? '' ?>">
                    <option value="" selected>Choose...</option>
                    <option value="Mr"> Mr</option>
                    <option value="Mrs"> Mrs</option>
                    <option value="miss"> Miss</option>
                    <option value="Dr"> Dr.</option>
                    <option value="Professor"> Professor</option>
                    <option value="Engr"> Engr.</option>
                    <option value="Barrister"> Barrister</option>
                    <option value="Hon"> Hon.</option>
                </select>
                <span class="error"><?= $title_error ?? '' ?></span>