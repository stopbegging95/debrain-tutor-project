<div class="container-fluid col-12" id="banContainerFluid" >
  <div class="container col-12 d-none d-md-block" id="banContainer">
    <div class="banner col-12 ">
            <img src="images/stu7.png"  />
    </div>
  </div>
  <div class="container col-12" id="registeredContainer">
    <div class="row col-12">
      <h3> EXAMINATION :: Online Registration.</h3>
      <div id="articleDiv" class="col-12">
                    
        <div class="col-xl-3 col-lg-3 col-md-3 col-sm-12 col-xs-12 d-none d-md-block" id="artImg">
          <img src="images/logo.png" alt="ijmb image">
        </div>
          <div id="artText" class="col-xl-9 col-lg-9 col-md-9 col-sm-12 col-xs-12">
            <p>
              <article>
              Applicant who are applying for the <b> A'level, International Exams, JAMB, or O'LEVEL </b> are advised to follow the rules and regulations that follows the payment before making payment. 
								<br> <br>
								<strong> NOTE:  </strong> After payment applicant should proceed to the application form to complete his or her registration, applicant most carefully fill the online application form to avoid error in the regisration thanks.
              </article>
            </p>
          </div>
          
      <!-- section for art goes here -->
        <div id="accord" class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12">
            <h3> Student Should follow the below listed procedure for his or her registration</h3>

            <ol class='col-xl-12 col-lg-12'>
              <li> Student online registration payment should be made through ATM Card, or any means of convenient online payment. </li>

              <li> Come along to school with the print out of your payment and application form printout.</li>

              <li> Admission Letter printout.</li>

              <li> Photocopy of your O'level Result (Awaiting Result Accepted for A'level) </li>
              
              <li> Bring along 8 Passports Photograph </li>

            </ol>

            <a href="selectprogram.php"> Apply Now</a> 
        </div>
<!-- section for address ends here -->
      </div>
    </div>
  </div>
</div>