vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|19 Oct 2017 11:23:28 -0000
vti_extenderversion:SR|12.0.0.0
vti_author:SR|DESKTOP-4KE05VC\\uismail
vti_modifiedby:SR|DESKTOP-4KE05VC\\uismail
vti_timecreated:TR|19 Oct 2017 11:23:28 -0000
vti_cacheddtm:TX|19 Oct 2017 11:23:28 -0000
vti_filesize:IR|111610
vti_backlinkinfo:VX|
