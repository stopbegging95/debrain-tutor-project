vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|16 Nov 2018 15:02:21 -0000
vti_extenderversion:SR|12.0.0.0
vti_author:SR|DESKTOP-4KE05VC\\uismail
vti_modifiedby:SR|DESKTOP-4KE05VC\\uismail
vti_timecreated:TR|16 Nov 2018 15:02:21 -0000
vti_cacheddtm:TX|16 Nov 2018 15:02:21 -0000
vti_filesize:IR|16371
vti_backlinkinfo:VX|
