<div class="container-fluid col-12" id="banContainerFluid" >
  <div class="container col-12 d-none d-md-block" id="banContainer">
    <div class="banner col-12 ">
            <img src="images/stu7.png" />
    </div>
  </div>
  <div class="container col-12" id="schoolContainer">
    <div class="row col-12">
      <h3> OUR SCHOOL FEES :: IJMB & JUPEB </h3>
      <div id="articleDiv" class="col-12">
                    
        <div class="col-xl-3 col-lg-3 col-md-3 col-sm-12 col-xs-12 d-none d-md-block" id="artImg">
          <img src="images/logo.png" alt="ijmb image">
        </div>
          <div id="artText" class="col-xl-9 col-lg-9 col-md-9 col-sm-12 col-xs-12">
            <p>
            DE-BRAIN-TUTOR ADVANCED STUDIES EDUCATIONAL SERVICES have made A'level program school fees payment easy for our student, by accepeting instalmental payment for our student after completing the online registration on our website, this opinion is made to make education easy, available and to balanced up the descrimination between the rich ones and the poor, so as to have equal education advantage.
            </p>
          </div>
          
      <!-- section for schoo fees goes here goes here -->
          <div id="accord" class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12">
            <h3> Check School Fees For Kwara State. </h3>

          <div class="row col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12 accordTable">

					<div class="accordion col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-10" id="accordionExample">
						<div class="card col-12">
						    <div class="card-header" id="headingOne">
						      <h2 class="mb-0">
						        <button class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                      IJMB & JUPEB  (Kwara State).
						        </button>
						      </h2>
						    </div>

						    <div id="collapseOne" class="collapse" aria-labelledby="headingOne" data-parent="#accordionExample">
							    <div class="card-body col-xl-5 col-lg-5 col-md-5 col-sm-12 col-xs-12">
                    <table class="table">
                      <thead>
                        <tr>
                          <th scope="col">S/N</th>
                          <th scope="col"> IJMB </th>
                          <th scope="col"> FEES </th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <th scope="row">1</th>
                          <td class="colmid">Application Form </td>
                          <td> N5,000.00</td>
                        </tr>
                        <tr>
                          <th scope="row">2</th>
                          <td class="colmid"> Text Book </td>
                          <td> N20,000.00 </td>
                        </tr>
                        <tr>
                          <th scope="row"> 3 </th>
                          <td class="colmid"> Hostel Fees	 </td>
                          <td> N30,000.00 </td>
                        </tr>
                        <tr>
                          <th scope="row">4</th>
                          <td class="colmid"> School Fees	 </td>
                          <td> N80,000.00 </td>
                        </tr>
                        <tr>
                          <th scope="row">5</th>
                          <td class="colmid"> Exam Registration Fees </td>
                          <td> N50,000.00 </td>
                        </tr>
                        <tr>
                          <th scope="row"> TOTAL </th>
                          <td class="colmid"> </td>
                          <td style="font-weight:bolder;"> N185,000.00 </td>
                        </tr>
                      </tbody>
                    </table>	
							    </div>
                  <!--  IJMB SCHOOL FEES SECTION ENDS HERE-->
                  <!-- JUPEB SCHOOL FEES SECTION GOES HERE -->
                  <div id="jupeb" class="card-body col-xl-5 col-lg-5 col-md-5 col-sm-12 col-xs-12">
                  <table class="table">
                      <thead>
                        <tr>
                          <th scope="col">S/N</th>
                          <th scope="col"> JUPEB </th>
                          <th scope="col"> FEES </th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <th scope="row">1</th>
                          <td class="colmid">Application Form </td>
                          <td> N10,000.00 </td>
                        </tr>
                        <tr>
                          <th scope="row">2</th>
                          <td class="colmid"> Text Book </td>
                          <td> N20,000.00 </td>
                        </tr>
                        <tr>
                          <th scope="row"> 3 </th>
                          <td class="colmid"> Hostel Fees	 </td>
                          <td> N30,000.00 </td>
                        </tr>
                        <tr>
                          <th scope="row">4</th>
                          <td class="colmid"> School Fees	 </td>
                          <td> N120,000.00 </td>
                        </tr>
                        <tr>
                          <th scope="row">5</th>
                          <td class="colmid"> Exam Registration Fees </td>
                          <td> N50,000.00 </td>
                        </tr>
                        <tr>
                          <th scope="row"> TOTAL </th>
                          <td class="colmid"> </td>
                          <td style="font-weight:bolder;"> N230,000.00 </td>
                        </tr>
                      </tbody>
                    </table>	
							    </div>
                  <!-- JUEPB SCHOOL FEES SECTION ENDS HERE -->
						    </div>
						  </div>
					  </div>
			    </div> 
        </div>

        <!-- FOR LAGOS STATE STARTS HERE  -->
                  <!-- section for schoo fees goes here goes here -->
          <div id="accord" class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12">
            <h3> Check School Fees For Lagos State (IKORODU). </h3>

          <div class="row col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12 accordTable">

					<div class="accordion col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-10" id="accordionExample">
						<div class="card col-12">
						    <div class="card-header" id="headingTwo">
						      <h2 class="mb-0">
						        <button class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="true" aria-controls="collapseTwo">
                      IJMB & JUPEB  (Lagos State) Ikorodu.
						        </button>
						      </h2>
						    </div>

						    <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionExample">
							    <div class="card-body col-xl-5 col-lg-5 col-md-5 col-sm-12 col-xs-12">
                    <table class="table">
                      <thead>
                        <tr>
                          <th scope="col">S/N</th>
                          <th scope="col"> IJMB </th>
                          <th scope="col"> FEES </th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <th scope="row">1</th>
                          <td class="colmid">Application Form </td>
                          <td> N5,000.00</td>
                        </tr>
                        <tr>
                          <th scope="row">2</th>
                          <td class="colmid"> Text Book </td>
                          <td> N20,000.00 </td>
                        </tr>
                        <tr>
                          <th scope="row"> 3 </th>
                          <td class="colmid"> Hostel Fees	 </td>
                          <td> N30,000.00 </td>
                        </tr>
                        <tr>
                          <th scope="row">4</th>
                          <td class="colmid"> School Fees	 </td>
                          <td> N100,000.00 </td>
                        </tr>
                        <tr>
                          <th scope="row">5</th>
                          <td class="colmid"> Exam Registration Fees </td>
                          <td> N50,000.00 </td>
                        </tr>
                        <tr>
                          <th scope="row"> TOTAL </th>
                          <td class="colmid"> </td>
                          <td style="font-weight:bolder;"> N205,000.00 </td>
                        </tr>
                      </tbody>
                    </table>	
							    </div>
                  <!--  IJMB SCHOOL FEES SECTION ENDS HERE-->
                  <!-- JUPEB SCHOOL FEES SECTION GOES HERE -->
                  <div id="jupeb" class="card-body col-xl-5 col-lg-5 col-md-5 col-sm-12 col-xs-12">
                  <table class="table">
                      <thead>
                        <tr>
                          <th scope="col">S/N</th>
                          <th scope="col"> JUPEB </th>
                          <th scope="col"> FEES </th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <th scope="row">1</th>
                          <td class="colmid">Application Form </td>
                          <td> N10,000.00 </td>
                        </tr>
                        <tr>
                          <th scope="row">2</th>
                          <td class="colmid"> Text Book </td>
                          <td> N20,000.00 </td>
                        </tr>
                        <tr>
                          <th scope="row"> 3 </th>
                          <td class="colmid"> Hostel Fees	 </td>
                          <td> N30,000.00 </td>
                        </tr>
                        <tr>
                          <th scope="row">4</th>
                          <td class="colmid"> School Fees	 </td>
                          <td> N150,000.00 </td>
                        </tr>
                        <tr>
                          <th scope="row">5</th>
                          <td class="colmid"> Exam Registration Fees </td>
                          <td> N50,000.00 </td>
                        </tr>
                        <tr>
                          <th scope="row"> TOTAL </th>
                          <td class="colmid"> </td>
                          <td style="font-weight:bolder;"> N260,000.00 </td>
                        </tr>
                      </tbody>
                    </table>	
							    </div>
                  <!-- JUEPB SCHOOL FEES SECTION ENDS HERE -->
						    </div>
						  </div>
					  </div>
			    </div> 
        </div>
        <!-- FOR LAGOS STATE ENDS (IKORODU) HERE  -->

          <!-- FOR LAGOS STATE (IJAYE) STARTS HERE  -->
          
          <div id="accord" class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12">
            <h3> Check School Fees For Lagos State (IJAYE). </h3>

          <div class="row col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12 accordTable">

					<div class="accordion col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-10" id="accordionExample">
						<div class="card col-12">
						    <div class="card-header" id="headingThree">
						      <h2 class="mb-0">
						        <button class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapseThree" aria-expanded="true" aria-controls="collapseThree">
                      IJMB & JUPEB  (Lagos State) IJAYE.
						        </button>
						      </h2>
						    </div>

						    <div id="collapseThree" class="collapse" aria-labelledby="headingThree" data-parent="#accordionExample">
							    <div class="card-body col-xl-5 col-lg-5 col-md-5 col-sm-12 col-xs-12">
                    <table class="table">
                      <thead>
                        <tr>
                          <th scope="col">S/N</th>
                          <th scope="col"> IJMB </th>
                          <th scope="col"> FEES </th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <th scope="row">1</th>
                          <td class="colmid">Application Form </td>
                          <td> N5,000.00</td>
                        </tr>
                        <tr>
                          <th scope="row">2</th>
                          <td class="colmid"> Text Book </td>
                          <td> N20,000.00 </td>
                        </tr>
                        <tr>
                          <th scope="row"> 3 </th>
                          <td class="colmid"> Hostel Fees	 </td>
                          <td> N30,000.00 </td>
                        </tr>
                        <tr>
                          <th scope="row">4</th>
                          <td class="colmid"> School Fees	 </td>
                          <td> N100,000.00 </td>
                        </tr>
                        <tr>
                          <th scope="row">5</th>
                          <td class="colmid"> Exam Registration Fees </td>
                          <td> N50,000.00 </td>
                        </tr>
                        <tr>
                          <th scope="row"> TOTAL </th>
                          <td class="colmid"> </td>
                          <td style="font-weight:bolder;"> N205,000.00 </td>
                        </tr>
                      </tbody>
                    </table>	
							    </div>
                  <!--  IJMB SCHOOL FEES SECTION ENDS HERE-->
                  <!-- JUPEB SCHOOL FEES SECTION GOES HERE -->
                  <div id="jupeb" class="card-body col-xl-5 col-lg-5 col-md-5 col-sm-12 col-xs-12">
                  <table class="table">
                      <thead>
                        <tr>
                          <th scope="col">S/N</th>
                          <th scope="col"> JUPEB </th>
                          <th scope="col"> FEES </th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <th scope="row">1</th>
                          <td class="colmid">Application Form </td>
                          <td> N10,000.00 </td>
                        </tr>
                        <tr>
                          <th scope="row">2</th>
                          <td class="colmid"> Text Book </td>
                          <td> N20,000.00 </td>
                        </tr>
                        <tr>
                          <th scope="row"> 3 </th>
                          <td class="colmid"> Hostel Fees	 </td>
                          <td> N30,000.00 </td>
                        </tr>
                        <tr>
                          <th scope="row">4</th>
                          <td class="colmid"> School Fees	 </td>
                          <td> N120,000.00 </td>
                        </tr>
                        <tr>
                          <th scope="row">5</th>
                          <td class="colmid"> Exam Registration Fees </td>
                          <td> N50,000.00 </td>
                        </tr>
                        <tr>
                          <th scope="row"> TOTAL </th>
                          <td class="colmid"> </td>
                          <td style="font-weight:bolder;"> N230,000.00 </td>
                        </tr>
                      </tbody>
                    </table>	
							    </div>
                  <!-- JUEPB SCHOOL FEES SECTION ENDS HERE -->
						    </div>
						  </div>
					  </div>
			    </div> 
        </div>
        <!-- FOR LAGOS STATE ENDS (IJAYE) HERE  -->

        <!-- FOR OGUN STATE STARTS HERE  -->
         
        <div id="accord" class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12">
            <h3> Check School Fees For Ogun State. </h3>

          <div class="row col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12 accordTable">

					<div class="accordion col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-10" id="accordionExample">
						<div class="card col-12">
						    <div class="card-header" id="headingFour">
						      <h2 class="mb-0">
						        <button class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapseFour" aria-expanded="true" aria-controls="collapseFour">
                      IJMB & JUPEB  (Ogun State).
						        </button>
						      </h2>
						    </div>

						    <div id="collapseFour" class="collapse" aria-labelledby="headingFour" data-parent="#accordionExample">
							    <div class="card-body col-xl-5 col-lg-5 col-md-5 col-sm-12 col-xs-12">
                    <table class="table">
                      <thead>
                        <tr>
                          <th scope="col">S/N</th>
                          <th scope="col"> IJMB </th>
                          <th scope="col"> FEES </th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <th scope="row">1</th>
                          <td class="colmid">Application Form </td>
                          <td> N5,000.00</td>
                        </tr>
                        <tr>
                          <th scope="row">2</th>
                          <td class="colmid"> Text Book </td>
                          <td> N20,000.00 </td>
                        </tr>
                        <tr>
                          <th scope="row"> 3 </th>
                          <td class="colmid"> Hostel Fees	 </td>
                          <td> N30,000.00 </td>
                        </tr>
                        <tr>
                          <th scope="row">4</th>
                          <td class="colmid"> School Fees	 </td>
                          <td> N80,000.00 </td>
                        </tr>
                        <tr>
                          <th scope="row">5</th>
                          <td class="colmid"> Exam Registration Fees </td>
                          <td> N50,000.00 </td>
                        </tr>
                        <tr>
                          <th scope="row"> TOTAL </th>
                          <td class="colmid"> </td>
                          <td style="font-weight:bolder;"> N185,000.00 </td>
                        </tr>
                      </tbody>
                    </table>	
							    </div>
                  <!--  IJMB SCHOOL FEES SECTION ENDS HERE-->
                  <!-- JUPEB SCHOOL FEES SECTION GOES HERE -->
                  <div id="jupeb" class="card-body col-xl-5 col-lg-5 col-md-5 col-sm-12 col-xs-12">
                  <table class="table">
                      <thead>
                        <tr>
                          <th scope="col">S/N</th>
                          <th scope="col"> JUPEB </th>
                          <th scope="col"> FEES </th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <th scope="row">1</th>
                          <td class="colmid">Application Form </td>
                          <td> N10,000.00 </td>
                        </tr>
                        <tr>
                          <th scope="row">2</th>
                          <td class="colmid"> Text Book </td>
                          <td> N20,000.00 </td>
                        </tr>
                        <tr>
                          <th scope="row"> 3 </th>
                          <td class="colmid"> Hostel Fees	 </td>
                          <td> N30,000.00 </td>
                        </tr>
                        <tr>
                          <th scope="row">4</th>
                          <td class="colmid"> School Fees	 </td>
                          <td> N150,000.00 </td>
                        </tr>
                        <tr>
                          <th scope="row">5</th>
                          <td class="colmid"> Exam Registration Fees </td>
                          <td> N50,000.00 </td>
                        </tr>
                        <tr>
                          <th scope="row"> TOTAL </th>
                          <td class="colmid"> </td>
                          <td style="font-weight:bolder;"> N260,000.00 </td>
                        </tr>
                      </tbody>
                    </table>	
							    </div>
                  <!-- JUEPB SCHOOL FEES SECTION ENDS HERE -->
						    </div>
						  </div>
					  </div>
			    </div> 
        </div>

        <!-- FOR OGUN STATE ENDS HERE  -->

          <!-- FOR OYO STATE STARTS HERE  -->
         
          <div id="accord" class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12">
            <h3> Check School Fees For Oyo State. </h3>

          <div class="row col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12 accordTable">

					<div class="accordion col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-10" id="accordionExample">
						<div class="card col-12">
						    <div class="card-header" id="headingFive">
						      <h2 class="mb-0">
						        <button class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapseFive" aria-expanded="true" aria-controls="collapseFive">
                      IJMB & JUPEB  (Oyo State).
						        </button>
						      </h2>
						    </div>

						    <div id="collapseFive" class="collapse" aria-labelledby="headingFive" data-parent="#accordionExample">
							    <div class="card-body col-xl-5 col-lg-5 col-md-5 col-sm-12 col-xs-12">
                    <table class="table">
                      <thead>
                        <tr>
                          <th scope="col">S/N</th>
                          <th scope="col"> IJMB </th>
                          <th scope="col"> FEES </th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <th scope="row">1</th>
                          <td class="colmid">Application Form </td>
                          <td> N5,000.00</td>
                        </tr>
                        <tr>
                          <th scope="row">2</th>
                          <td class="colmid"> Text Book </td>
                          <td> N20,000.00 </td>
                        </tr>
                        <tr>
                          <th scope="row"> 3 </th>
                          <td class="colmid"> Hostel Fees	 </td>
                          <td> N30,000.00 </td>
                        </tr>
                        <tr>
                          <th scope="row">4</th>
                          <td class="colmid"> School Fees	 </td>
                          <td> N80,000.00 </td>
                        </tr>
                        <tr>
                          <th scope="row">5</th>
                          <td class="colmid"> Exam Registration Fees </td>
                          <td> N50,000.00 </td>
                        </tr>
                        <tr>
                          <th scope="row"> TOTAL </th>
                          <td class="colmid"> </td>
                          <td style="font-weight:bolder;"> N185,000.00 </td>
                        </tr>
                      </tbody>
                    </table>	
							    </div>
                  <!--  IJMB SCHOOL FEES SECTION ENDS HERE-->
                  <!-- JUPEB SCHOOL FEES SECTION GOES HERE -->
                  <div id="jupeb" class="card-body col-xl-5 col-lg-5 col-md-5 col-sm-12 col-xs-12">
                  <table class="table">
                      <thead>
                        <tr>
                          <th scope="col">S/N</th>
                          <th scope="col"> JUPEB </th>
                          <th scope="col"> FEES </th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <th scope="row">1</th>
                          <td class="colmid">Application Form </td>
                          <td> N10,000.00 </td>
                        </tr>
                        <tr>
                          <th scope="row">2</th>
                          <td class="colmid"> Text Book </td>
                          <td> N20,000.00 </td>
                        </tr>
                        <tr>
                          <th scope="row"> 3 </th>
                          <td class="colmid"> Hostel Fees	 </td>
                          <td> N30,000.00 </td>
                        </tr>
                        <tr>
                          <th scope="row">4</th>
                          <td class="colmid"> School Fees	 </td>
                          <td> N120,000.00 </td>
                        </tr>
                        <tr>
                          <th scope="row">5</th>
                          <td class="colmid"> Exam Registration Fees </td>
                          <td> N50,000.00 </td>
                        </tr>
                        <tr>
                          <th scope="row"> TOTAL </th>
                          <td class="colmid"> </td>
                          <td style="font-weight:bolder;"> N230,000.00 </td>
                        </tr>
                      </tbody>
                    </table>	
							    </div>
                  <!-- JUEPB SCHOOL FEES SECTION ENDS HERE -->
						    </div>
						  </div>
					  </div>
			    </div> 
        </div>
        <!-- FOR OYO STATE ENDS HERE  -->

        
          <!-- FOR FTC (ABUJE) STARTS HERE  -->
         
          <div id="accord" class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12">
            <h3> Check School Fees For FCT (ABUJA). </h3>

          <div class="row col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12 accordTable">

					<div class="accordion col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-10" id="accordionExample">
						<div class="card col-12">
						    <div class="card-header" id="headingSix">
						      <h2 class="mb-0">
						        <button class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapseSix" aria-expanded="true" aria-controls="collapseSix">
                      IJMB & JUPEB  FCT (Abuja).
						        </button>
						      </h2>
						    </div>

						    <div id="collapseSix" class="collapse" aria-labelledby="headingSix" data-parent="#accordionExample">
							    <div class="card-body col-xl-5 col-lg-5 col-md-5 col-sm-12 col-xs-12">
                    <table class="table">
                      <thead>
                        <tr>
                          <th scope="col">S/N</th>
                          <th scope="col"> IJMB </th>
                          <th scope="col"> FEES </th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <th scope="row">1</th>
                          <td class="colmid">Application Form </td>
                          <td> N5,000.00</td>
                        </tr>
                        <tr>
                          <th scope="row">2</th>
                          <td class="colmid"> Text Book </td>
                          <td> N20,000.00 </td>
                        </tr>
                        <tr>
                          <th scope="row"> 3 </th>
                          <td class="colmid"> Hostel Fees	 </td>
                          <td> N80,000.00 </td>
                        </tr>
                        <tr>
                          <th scope="row">4</th>
                          <td class="colmid"> School Fees	 </td>
                          <td> N120,000.00 </td>
                        </tr>
                        <tr>
                          <th scope="row">5</th>
                          <td class="colmid"> Exam Registration Fees </td>
                          <td> N50,000.00 </td>
                        </tr>
                        <tr>
                          <th scope="row"> TOTAL </th>
                          <td class="colmid"> </td>
                          <td style="font-weight:bolder;"> N275,000.00 </td>
                        </tr>
                      </tbody>
                    </table>	
							    </div>
                  <!--  IJMB SCHOOL FEES SECTION ENDS HERE-->
                  <!-- JUPEB SCHOOL FEES SECTION GOES HERE -->
                  <div id="jupeb" class="card-body col-xl-5 col-lg-5 col-md-5 col-sm-12 col-xs-12">
                  <table class="table">
                      <thead>
                        <tr>
                          <th scope="col">S/N</th>
                          <th scope="col"> JUPEB </th>
                          <th scope="col"> FEES </th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <th scope="row">1</th>
                          <td class="colmid">Application Form </td>
                          <td> N10,000.00 </td>
                        </tr>
                        <tr>
                          <th scope="row">2</th>
                          <td class="colmid"> Text Book </td>
                          <td> N20,000.00 </td>
                        </tr>
                        <tr>
                          <th scope="row"> 3 </th>
                          <td class="colmid"> Hostel Fees	 </td>
                          <td> N80,000.00 </td>
                        </tr>
                        <tr>
                          <th scope="row">4</th>
                          <td class="colmid"> School Fees	 </td>
                          <td> N170,000.00 </td>
                        </tr>
                        <tr>
                          <th scope="row">5</th>
                          <td class="colmid"> Exam Registration Fees </td>
                          <td> N50,000.00 </td>
                        </tr>
                        <tr>
                          <th scope="row"> TOTAL </th>
                          <td class="colmid"> </td>
                          <td style="font-weight:bolder;"> N330,000.00 </td>
                        </tr>
                      </tbody>
                    </table>	
							    </div>
                  <!-- JUEPB SCHOOL FEES SECTION ENDS HERE -->
						    </div>
						  </div>
					  </div>
			    </div> 
        </div>
        <!-- SCHOOL FEES FOR FCT (ABUJA) STATE ENDS HERE  -->

        <!-- SCHOOL FEES FOR AKWAIBOM STATE  AKWA STATE STARTS HERE  -->
        <div id="accord" class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12">
            <h3> Check School Fees For Akwa-Ibom State. </h3>

          <div class="row col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12 accordTable">

					<div class="accordion col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-10" id="accordionExample">
						<div class="card col-12">
						    <div class="card-header" id="headingSeven">
						      <h2 class="mb-0">
						        <button class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapseSeven" aria-expanded="true" aria-controls="collapseSeven">
                      IJMB & JUPEB  Akwa-Ibom State.
						        </button>
						      </h2>
						    </div>

						    <div id="collapseSeven" class="collapse" aria-labelledby="headingSeven" data-parent="#accordionExample">
							    <div class="card-body col-xl-5 col-lg-5 col-md-5 col-sm-12 col-xs-12">
                    <table class="table">
                      <thead>
                        <tr>
                          <th scope="col">S/N</th>
                          <th scope="col"> IJMB </th>
                          <th scope="col"> FEES </th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <th scope="row">1</th>
                          <td class="colmid">Application Form </td>
                          <td> N5,000.00</td>
                        </tr>
                        <tr>
                          <th scope="row">2</th>
                          <td class="colmid"> Text Book </td>
                          <td> N20,000.00 </td>
                        </tr>
                        <tr>
                          <th scope="row"> 3 </th>
                          <td class="colmid"> Hostel Fees	 </td>
                          <td> N30,000.00 </td>
                        </tr>
                        <tr>
                          <th scope="row">4</th>
                          <td class="colmid"> School Fees	 </td>
                          <td> N100,000.00 </td>
                        </tr>
                        <tr>
                          <th scope="row">5</th>
                          <td class="colmid"> Exam Registration Fees </td>
                          <td> N50,000.00 </td>
                        </tr>
                        <tr>
                          <th scope="row"> TOTAL </th>
                          <td class="colmid"> </td>
                          <td style="font-weight:bolder;"> N205,000.00 </td>
                        </tr>
                      </tbody>
                    </table>	
							    </div>
                  <!--  IJMB SCHOOL FEES SECTION ENDS HERE-->
                  <!-- JUPEB SCHOOL FEES SECTION GOES HERE -->
                  <div id="jupeb" class="card-body col-xl-5 col-lg-5 col-md-5 col-sm-12 col-xs-12">
                  <table class="table">
                      <thead>
                        <tr>
                          <th scope="col">S/N</th>
                          <th scope="col"> JUPEB </th>
                          <th scope="col"> FEES </th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <th scope="row">1</th>
                          <td class="colmid">Application Form </td>
                          <td> N10,000.00 </td>
                        </tr>
                        <tr>
                          <th scope="row">2</th>
                          <td class="colmid"> Text Book </td>
                          <td> N20,000.00 </td>
                        </tr>
                        <tr>
                          <th scope="row"> 3 </th>
                          <td class="colmid"> Hostel Fees	 </td>
                          <td> N30,000.00 </td>
                        </tr>
                        <tr>
                          <th scope="row">4</th>
                          <td class="colmid"> School Fees	 </td>
                          <td> N150,000.00 </td>
                        </tr>
                        <tr>
                          <th scope="row">5</th>
                          <td class="colmid"> Exam Registration Fees </td>
                          <td> N50,000.00 </td>
                        </tr>
                        <tr>
                          <th scope="row"> TOTAL </th>
                          <td class="colmid"> </td>
                          <td style="font-weight:bolder;"> N260,000.00 </td>
                        </tr>
                      </tbody>
                    </table>	
							    </div>
                  <!-- JUEPB SCHOOL FEES SECTION ENDS HERE -->
						    </div>
						  </div>
					  </div>
			    </div> 
        </div>
    
        <!-- SCHOOL FEES FOR AKWAIBOM STATE ENDS HERE  -->

        <!-- SCHOOL FEES FOR DELTA STATE (AGBARHO) GOES  HERE  -->
        <div id="accord" class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12">
            <h3> Check School Fees For Delta State. (AGBARHO) </h3>

          <div class="row col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12 accordTable">

					<div class="accordion col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-10" id="accordionExample">
						<div class="card col-12">
						    <div class="card-header" id="headingEight">
						      <h2 class="mb-0">
						        <button class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapseEight" aria-expanded="true" aria-controls="collapseEight">
                      IJMB & JUPEB  Delta State (AGBARHO).
						        </button>
						      </h2>
						    </div>

						    <div id="collapseEight" class="collapse" aria-labelledby="headingEight" data-parent="#accordionExample">
							    <div class="card-body col-xl-5 col-lg-5 col-md-5 col-sm-12 col-xs-12">
                    <table class="table">
                      <thead>
                        <tr>
                          <th scope="col">S/N</th>
                          <th scope="col"> IJMB </th>
                          <th scope="col"> FEES </th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <th scope="row">1</th>
                          <td class="colmid">Application Form </td>
                          <td> N5,000.00</td>
                        </tr>
                        <tr>
                          <th scope="row">2</th>
                          <td class="colmid"> Text Book </td>
                          <td> N20,000.00 </td>
                        </tr>
                        <tr>
                          <th scope="row"> 3 </th>
                          <td class="colmid"> Hostel Fees	 </td>
                          <td> N30,000.00 </td>
                        </tr>
                        <tr>
                          <th scope="row">4</th>
                          <td class="colmid"> School Fees	 </td>
                          <td> N120,000.00 </td>
                        </tr>
                        <tr>
                          <th scope="row">5</th>
                          <td class="colmid"> Exam Registration Fees </td>
                          <td> N50,000.00 </td>
                        </tr>
                        <tr>
                          <th scope="row"> TOTAL </th>
                          <td class="colmid"> </td>
                          <td style="font-weight:bolder;"> N225,000.00 </td>
                        </tr>
                      </tbody>
                    </table>	
							    </div>
                  <!--  IJMB SCHOOL FEES SECTION ENDS HERE-->
                  <!-- JUPEB SCHOOL FEES SECTION GOES HERE -->
                  <div id="jupeb" class="card-body col-xl-5 col-lg-5 col-md-5 col-sm-12 col-xs-12">
                  <table class="table">
                      <thead>
                        <tr>
                          <th scope="col">S/N</th>
                          <th scope="col"> JUPEB </th>
                          <th scope="col"> FEES </th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <th scope="row">1</th>
                          <td class="colmid">Application Form </td>
                          <td> N10,000.00 </td>
                        </tr>
                        <tr>
                          <th scope="row">2</th>
                          <td class="colmid"> Text Book </td>
                          <td> N20,000.00 </td>
                        </tr>
                        <tr>
                          <th scope="row"> 3 </th>
                          <td class="colmid"> Hostel Fees	 </td>
                          <td> N30,000.00 </td>
                        </tr>
                        <tr>
                          <th scope="row">4</th>
                          <td class="colmid"> School Fees	 </td>
                          <td> N150,000.00 </td>
                        </tr>
                        <tr>
                          <th scope="row">5</th>
                          <td class="colmid"> Exam Registration Fees </td>
                          <td> N50,000.00 </td>
                        </tr>
                        <tr>
                          <th scope="row"> TOTAL </th>
                          <td class="colmid"> </td>
                          <td style="font-weight:bolder;"> N260,000.00 </td>
                        </tr>
                      </tbody>
                    </table>	
							    </div>
                  <!-- JUEPB SCHOOL FEES SECTION ENDS HERE -->
						    </div>
						  </div>
					  </div>
			    </div> 
        </div>
        <!-- SCHOOL FEES FOR DELTA STATE (AGBARHO) ENDS  HERE  -->

        <!-- SCHOOL FEES FOR DELTA STATE (ASABA) GOES  HERE  -->

        <div id="accord" class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12">
            <h3> Check School Fees For Delta State (ASABA). </h3>

          <div class="row col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12 accordTable">

					<div class="accordion col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-10" id="accordionExample">
						<div class="card col-12">
						    <div class="card-header" id="headingNine">
						      <h2 class="mb-0">
						        <button class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapseNine" aria-expanded="true" aria-controls="collapseNine">
                      IJMB & JUPEB  Delta State (ASABA).
						        </button>
						      </h2>
						    </div>

						    <div id="collapseNine" class="collapse" aria-labelledby="headingNine" data-parent="#accordionExample">
							    <div class="card-body col-xl-5 col-lg-5 col-md-5 col-sm-12 col-xs-12">
                    <table class="table">
                      <thead>
                        <tr>
                          <th scope="col">S/N</th>
                          <th scope="col"> IJMB </th>
                          <th scope="col"> FEES </th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <th scope="row">1</th>
                          <td class="colmid">Application Form </td>
                          <td> N5,000.00</td>
                        </tr>
                        <tr>
                          <th scope="row">2</th>
                          <td class="colmid"> Text Book </td>
                          <td> N20,000.00 </td>
                        </tr>
                        <tr>
                          <th scope="row"> 3 </th>
                          <td class="colmid"> Hostel Fees	 </td>
                          <td> N30,000.00 </td>
                        </tr>
                        <tr>
                          <th scope="row">4</th>
                          <td class="colmid"> School Fees	 </td>
                          <td> N150,000.00 </td>
                        </tr>
                        <tr>
                          <th scope="row">5</th>
                          <td class="colmid"> Exam Registration Fees </td>
                          <td> N50,000.00 </td>
                        </tr>
                        <tr>
                          <th scope="row"> TOTAL </th>
                          <td class="colmid"> </td>
                          <td style="font-weight:bolder;"> N255,000.00 </td>
                        </tr>
                      </tbody>
                    </table>	
							    </div>
                  <!--  IJMB SCHOOL FEES SECTION ENDS HERE-->
                  <!-- JUPEB SCHOOL FEES SECTION GOES HERE -->
                  <div id="jupeb" class="card-body col-xl-5 col-lg-5 col-md-5 col-sm-12 col-xs-12">
                  <table class="table">
                      <thead>
                        <tr>
                          <th scope="col">S/N</th>
                          <th scope="col"> JUPEB </th>
                          <th scope="col"> FEES </th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <th scope="row">1</th>
                          <td class="colmid">Application Form </td>
                          <td> N10,000.00 </td>
                        </tr>
                        <tr>
                          <th scope="row">2</th>
                          <td class="colmid"> Text Book </td>
                          <td> N20,000.00 </td>
                        </tr>
                        <tr>
                          <th scope="row"> 3 </th>
                          <td class="colmid"> Hostel Fees	 </td>
                          <td> N30,000.00 </td>
                        </tr>
                        <tr>
                          <th scope="row">4</th>
                          <td class="colmid"> School Fees	 </td>
                          <td> N170,000.00 </td>
                        </tr>
                        <tr>
                          <th scope="row">5</th>
                          <td class="colmid"> Exam Registration Fees </td>
                          <td> N50,000.00 </td>
                        </tr>
                        <tr>
                          <th scope="row"> TOTAL </th>
                          <td class="colmid"> </td>
                          <td style="font-weight:bolder;"> N280,000.00 </td>
                        </tr>
                      </tbody>
                    </table>	
							    </div>
                  <!-- JUEPB SCHOOL FEES SECTION ENDS HERE -->
						    </div>
						  </div>
					  </div>
			    </div> 
        </div>

    <!-- SCHOOL FEES FOR DELTA STATE (ASABA) ENDS  HERE  -->

    <!-- SCHOOL FEES FOR RIVER STATE (PORT HARCOURT) GOES  HERE  -->

    <div id="accord" class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12">
            <h3> Check School Fees For River State (PORT HARCOURT). </h3>

          <div class="row col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12 accordTable">

					<div class="accordion col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-10" id="accordionExample">
						<div class="card col-12">
						    <div class="card-header" id="headingTen">
						      <h2 class="mb-0">
						        <button class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapseTen" aria-expanded="true" aria-controls="collapseTen">
                      IJMB & JUPEB  River State (PORT HARCOURT).
						        </button>
						      </h2>
						    </div>

						    <div id="collapseTen" class="collapse" aria-labelledby="headingTen" data-parent="#accordionExample">
							    <div class="card-body col-xl-5 col-lg-5 col-md-5 col-sm-12 col-xs-12">
                    <table class="table">
                      <thead>
                        <tr>
                          <th scope="col">S/N</th>
                          <th scope="col"> IJMB </th>
                          <th scope="col"> FEES </th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <th scope="row">1</th>
                          <td class="colmid">Application Form </td>
                          <td> N5,000.00</td>
                        </tr>
                        <tr>
                          <th scope="row">2</th>
                          <td class="colmid"> Text Book </td>
                          <td> N20,000.00 </td>
                        </tr>
                        <tr>
                          <th scope="row"> 3 </th>
                          <td class="colmid"> Hostel Fees	 </td>
                          <td> N30,000.00 </td>
                        </tr>
                        <tr>
                          <th scope="row">4</th>
                          <td class="colmid"> School Fees	 </td>
                          <td> N150,000.00 </td>
                        </tr>
                        <tr>
                          <th scope="row">5</th>
                          <td class="colmid"> Exam Registration Fees </td>
                          <td> N50,000.00 </td>
                        </tr>
                        <tr>
                          <th scope="row"> TOTAL </th>
                          <td class="colmid"> </td>
                          <td style="font-weight:bolder;"> N255,000.00 </td>
                        </tr>
                      </tbody>
                    </table>	
							    </div>
                  <!--  IJMB SCHOOL FEES SECTION ENDS HERE-->
                  <!-- JUPEB SCHOOL FEES SECTION GOES HERE -->
                  <div id="jupeb" class="card-body col-xl-5 col-lg-5 col-md-5 col-sm-12 col-xs-12">
                  <table class="table">
                      <thead>
                        <tr>
                          <th scope="col">S/N</th>
                          <th scope="col"> JUPEB </th>
                          <th scope="col"> FEES </th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <th scope="row">1</th>
                          <td class="colmid">Application Form </td>
                          <td> N10,000.00 </td>
                        </tr>
                        <tr>
                          <th scope="row">2</th>
                          <td class="colmid"> Text Book </td>
                          <td> N20,000.00 </td>
                        </tr>
                        <tr>
                          <th scope="row"> 3 </th>
                          <td class="colmid"> Hostel Fees	 </td>
                          <td> N30,000.00 </td>
                        </tr>
                        <tr>
                          <th scope="row">4</th>
                          <td class="colmid"> School Fees	 </td>
                          <td> N180,000.00 </td>
                        </tr>
                        <tr>
                          <th scope="row">5</th>
                          <td class="colmid"> Exam Registration Fees </td>
                          <td> N50,000.00 </td>
                        </tr>
                        <tr>
                          <th scope="row"> TOTAL </th>
                          <td class="colmid"> </td>
                          <td style="font-weight:bolder;"> N290,000.00 </td>
                        </tr>
                      </tbody>
                    </table>	
							    </div>
                  <!-- JUEPB SCHOOL FEES SECTION ENDS HERE -->
						    </div>
						  </div>
					  </div>
			    </div> 
        </div>

    <!-- SCHOOL FEES FOR RIVER STATE (PORT HARCOURT) ENDS  HERE  -->
<!-- section for sechool fees  ends here -->

      </div>
    </div>
  </div>
</div>