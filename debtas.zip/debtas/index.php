<?php include("includes/header.php"); ?>

  <main>
<!-- #BeginEditable "body" -->
    <?php include("banner.php"); ?>
    <?php include("mentorship.php"); ?>
    <?php include("examoffer.php"); ?>
    <?php include("sertest.php"); ?>
    <?php include("advantages.php"); ?>
    
<!-- #EndEditable -->
	</main>
  <?php include("includes/footer.php"); ?>