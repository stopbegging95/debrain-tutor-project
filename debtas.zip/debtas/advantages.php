
      <div class="container col-12" id="workingContainer">
        <div class="row" id="workRow">
            <div class="workings col-xl-4 col-lg-4 col-md-4 col-sm-12 col-xs-12">
                <h3>Our Advantages</h3>
                <ul>
                    <li> <span class="fa fa-check-square-o"></span> Free Consultation </li>
                    <li> <span class="fa fa-check-square-o"></span>Useful Information</li>
                    <li> <span class="fa fa-check-square-o"></span>Affordable Price Estimate </li>
                    <li> <span class="fa fa-check-square-o"></span>Instalmental School Fees Payment</li>
                </ul>
            </div>
            <div id="openHour" class="workings col-xl-4 col-lg-4 col-md-4 col-sm-12 col-xs-12">
                <h3>Open Hours</h3>
                <ul>
                    <li> <span class="fa fa-check-square-o"></span> Weekdays: 08:00am - 06:00pm </li>
                    <li> <span class="fa fa-check-square-o"></span> Saturdays: 10:00am - 06:00pm</li>
                    <li> <span class="fa fa-check-square-o"></span> Sundays: 12:00am - 04:00pm </li>
                    <li> <span class="fa fa-check-square-o"></span> E-Messages 00:01am - 11:59am</li>
                </ul>
            </div>
            <div id="getIntouch" class="workings col-xl-4 col-lg-4 col-md-4 col-sm-12 col-xs-12">
                <h3>Get In Touch</h3>
                <ul>
                    <li> <span class="fa fa-headphones"></span> 0905-997-1709 | 0816-537-1302  </li>
                    <li> <span class="fa fa-envelope-o"></span> debraintutoradvancedstudies@gmail.com </li>
                    <li> <span class="fa fa-whatsapp"></span> 0907-850-4153 </li>
                </ul>
            </div>
        </div>
      </div>