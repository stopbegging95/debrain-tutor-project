<?php include("includes/header.php"); ?>
  <main>
  <div class="container-fluid col-12" id="banContainerFluid" >
  <div class="container col-12 d-none d-md-block" id="banContainer">
    <div class="banner col-12">
            <img src="images/stu7.png" />
    </div>
  </div>
  <div class="container col-12" id="registrationContainer">
    <div class="row col-12">
      <h3> START REGISTRATION :: Reg. Sign Up </h3>
      <div id="articleDiv" class="col-12">
                    
        <!-- <div class="col-xl-3 col-lg-3 col-md-3 col-sm-12 col-xs-12" id="artImg">
          <img src="images/logo.png" alt="ijmb image">
        </div> -->
          <div id="artText" class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12">
          <div class="login-box">
            <form id="paymentForm" action="payment.php" method="POST">
                <!-- <img src="images/logo.png" class="mx-auto d-block"> -->
                <h2> Create Account</h2>
                
                <div class="user-box">
                    <input type="text" name="first_name" id="first_name" required="required">
                    <label for="first-name"> First Name</label>
                  </div>
                  <div class="user-box">
                    <input type="text" name="second_name" id="second_name" required="required">
                    <label for="second-name">Second Name</label>
                  </div>
                  <div class="user-box">
                    <input type="text" name="last_name" id="last_name" required="required">
                    <label for="last-name">Last Name</label>
                  </div>
                  <div class="user-box">
                    <input type="email" name="email" id="email_address" required="required">
                    <label for="email">Email Address</label>
                  </div>
                <!--   <div class="form-group">
                    <label for="amount">Amount:</label>
                    <input type="tel" name="amount" id="amount">
                  </div> -->
                  <div class="user-box">
                    <input type="tel" name="phone" id="phone" required="required" >
                    <label for="phone">Phone No</label>
                  </div>
                  <div class="form-submit">
                    <button name="sub"> Submit </button>
                    <!-- <button type="submit" onclick="payWithPaystack()"> Pay </button> -->
                  </div>
              </form>
            </div>
          </div>
        
<!-- section for address ends here -->
      </div>
    </div>
  </div>
</div>
  </main>
<?php include("includes/footer.php"); ?>