<?php include("includes/header.php"); ?>
  <main>
      <?php include("university.php"); ?> 
  </main>
<?php include("includes/footer.php"); ?>