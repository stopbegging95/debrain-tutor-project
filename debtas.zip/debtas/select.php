<div class="container-fluid col-12" id="banContainerFluid" >
  <div class="container col-12 d-none d-md-block" id="banContainer">
    <div class="banner col-12">
            <img src="images/stu7.png" />
    </div>
  </div>
  <div class="container col-12" id="selectContainer">
    <div class="row col-12">
      <h3> SELECT PROGRAM :: For Registration </h3>
      <div id="articleDiv" class="col-12">
                    
        <!-- <div class="col-xl-3 col-lg-3 col-md-3 col-sm-12 col-xs-12" id="artImg">
          <img src="images/logo.png" alt="ijmb image">
        </div> --> 
          <div id="artText" class="col-xl-9 col-lg-9 col-md-12 col-sm-12 col-xs-12">
            <p>
              <article>
              Applicant should select preferred choice of programe to proceed for registration :
								<!-- <br> <br>
								<strong> NOTE:  </strong> After payment applicant should proceed to the application form to complete his or her registration, applicant most carefully fill the online application form to avoid error in the regisration thanks. -->
              </article>
            </p>
          </div>
          
      <!-- section for art goes here -->
        <div id="accord" class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12">
            
          <div class="buttonDiv row col-12">
              <a href="registration.php" type="button" class="btn btn-danger btn-lg ">I J M B</a>

              <a href="registration.php" type="button" class="btn btn-danger btn-lg ">J U P E B </a>

              <a href="registration.php" type="button" class="btn btn-danger btn-lg disabled "> I E L T S</a>
 
              <a href="registration.php" type="button" class="btn btn-danger btn-lg disabled"> T O E F L</a>
              
              <a href="registration.php" type="button" class="btn btn-danger btn-lg disabled "> G M A T </a>

              <a href="registration.php" type="button" class="btn btn-danger btn-lg disabled "> J A M B </a>

              <a href="registration.php" type="button" class="btn btn-danger btn-lg disabled "> W A E C </a>

              <a href="registration.php" type="button" class="btn btn-danger btn-lg disabled "> N E C O </a>
                
              <a href="registration.php" type="button" class="btn btn-danger btn-lg disabled"> N A B T E B  </a>
              
              <a href="registration.php" type="button" class="btn btn-danger btn-lg disabled "> G C E  </a>
              
              <a href="registration.php" type="button" class="btn btn-danger btn-lg disabled"> S A T</a>

              <a href="registration.php" type="button" class="btn btn-danger btn-lg disabled"> G R E</a>
              
            
              </div>

            <!-- <a href="#" id="apply"> Apply Now</a>  -->
        </div>
<!-- section for address ends here -->
      </div>
    </div>
  </div>
</div>