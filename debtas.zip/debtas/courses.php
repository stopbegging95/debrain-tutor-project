<div class="container-fluid col-12" id="banContainerFluid" >
  <div class="container col-12 d-none d-md-block" id="banContainer">
    <div class="banner col-12">
            <img src="images/stu7.png" />
    </div>
  </div>
  <div class="container col-12" id="ijpebContainer">
    <div class="row col-12">
      <h3> IJMB || JUPEB :: Courses</h3>
      <div id="articleDiv" class="col-12">
                    
        <div class="col-xl-2 col-lg-2 col-md-2 col-sm-12 col-xs-12 d-none d-md-block" id="artImg">
          <img src="images/ijmb.png" alt="ijmb image">
        </div>
        <div class="col-xl-2 col-lg-2 col-md-2 col-sm-12 col-xs-12 d-none d-md-block" id="artImg">
            <img src="images/jupeblogo.png" alt="jupeb image">
        </div>
          <div id="artText" class="col-xl-8 col-lg-8 col-md-8 col-sm-12 col-xs-12">
            <p>
            IJMB and JUPEB courses are available here for candidates to select which of the courses the student will likely to enroll in during the IJMB and JUPEB application form. With IJMB and JUPEB, we have made it known in several places and states that there is no course in Nigeria that students cannot apply for in Universities in Nigeria with IJMB and JUPEB results.
            The IJMB and JUPEB courses are the course you can apply for with an IJMB and JUPEB result, just like it has been said above. You can see all list of IJMB and JUPEB courses students can apply for below with IJMB and JUPEB.
            </p>
          </div>
          
      <!-- section for art goes here -->
          <div id="accord" class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12">
            <h3> ART :: Courses</h3>

          <div class="row col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12 accordTable">

					<div class="accordion col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12" id="accordionExample">
						<div class="card col-12">
						    <div class="card-header" id="headingOne">
						      <h2 class="mb-0">
						        <button class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
						          List Of Available Courses For Art Department
						        </button>
						      </h2>
						    </div>

						    <div id="collapseOne" class="collapse" aria-labelledby="headingOne" data-parent="#accordionExample">
							    <div class="card-body">
                    <table class="table">
                      <thead>
                        <tr>
                          <th scope="col">CODE</th>
                          <th scope="col">SUBJECT COMBINATION </th>
                          <th scope="col">POSIBLE UNDERGRADUATE COURSES </th>
                        </tr>
                      </thead>
                      <tbody id="tbodyyart">
                        <tr>
                          <th scope="row">045</th>
                          <td class="colmid">CRS, GOVT, LIT </td>
                          <td> LAW, B.SC PA, POL SCI, INTER STUDIES </td>
                        </tr>
                        <tr>
                          <th scope="row">060</th>
                          <td class="colmid">GEO, GOVT, A/L MATHS </td>
                          <td> ENVL SCI, POL SCI, INTER STUDIES, GEO, PA </td>
                        </tr>
                        <tr>
                          <th scope="row"> 061 </th>
                          <td class="colmid"> GEO, GOVT, SOCIOLOGY </td>
                          <td> (SINGLE HONOURS) POL SCI, INTER STUDIES, PA, LAW </td>
                        </tr>
                      </tbody>
                    </table>	

							    </div>
						    </div>
						  </div>
					  </div>
			    </div> 
        </div>
<!-- section for art ends here -->

<!-- section for science goes here -->

<div id="accord" class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12">
            <h3> SCIENCE :: Courses</h3>

          <div class="row col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12 accordTable">

					<div class="accordion col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-10" id="accordionExample2">
						<div class="card col-12">
						    <div class="card-header" id="headingTwo">
						      <h2 class="mb-0">
						        <button class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="true" aria-controls="collapseTwo">
                      List Of Available Courses For Science Department
						        </button>
						      </h2>
						    </div>

						    <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionExample2">
							    <div class="card-body">
                <table class="table">
								  <thead>
								    <tr>
								      <th scope="col">CODE</th>
								      <th scope="col">SUBJECT COMBINATION </th>
								      <th scope="col">POSIBLE UNDERGRADUATE COURSES </th>
								    </tr>
								  </thead>
								  <tbody  id="tbodyyscience">
								    <tr>
								      <th scope="row"> 027 </th>
								      <td class="colmid"> 	BIO, CHEM, A/L MATHS </td>
								      <td> MEDICINE, VET MED, PHARM, BIOCHEM, MCB, AGRIC SCI, TXT SCI </td>
								    </tr>
								    <tr>
								      <th scope="row">028</th>
								      <td class="colmid"> BIO, CHEM, GEO </td>
								      <td> AGRIC SCI, ARCHAELOGY, BIOCHEM, MCB, PHYSICOLOGY (SINGLE HONOURS) </td>
								    </tr>
								     <tr>
								      <th scope="row">030</th>
								      <td class="colmid">  BIO, CHEM, PHY </td>
								      <td> MED, AGRIC SCI, TXT SCI AND TECH, PHARM, BIOCHEM, ARCHAEOLOGY </td>
								    </tr>
								     <tr>
								      <th scope="row">043</th>
								      <td class="colmid"> CHEM, PHY, A/L MATHS </td>
								      <td> ENGINEERING, ENVIRONMENTAL SCI, TXT SCI, COMPUTER SCI, COMPUTER ENG </td>
								    </tr>
								     <tr>
								      <th scope="row">039</th>
								      <td class="colmid"> CHEM, GEO, A/L MATHS </td>
								      <td>  ENVIRONMENTAL SCI, AGRIC SCI </td>
								    </tr>
								     <tr>
								      <th scope="row">040</th>
								      <td class="colmid"> CHEM, PHY, GEO </td>
								      <td>  ENVL SCI, ENGR, AGRIC SCI, ARCHAEOLOGY </td>
								    </tbody>
							    </table>

							    </div>
						    </div>
						  </div>
					  </div>
			    </div> 
        </div>
<!-- section for science ends here -->
<!-- section for commercial goes here -->

<div id="accord" class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12">
            <h3> COMMERCIAL :: Courses</h3>

          <div class="row col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12 accordTable" id="accordionExample3">

					<div class="accordion col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-10" id="accordionExample3">
						<div class="card col-12">
						    <div class="card-header" id="headingThree">
						      <h2 class="mb-0">
						        <button class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapseThree" aria-expanded="true" aria-controls="collapseThree">
                      List Of Available Courses For commercial Department
						        </button>
						      </h2>
						    </div>

						    <div id="collapseThree" class="collapse" aria-labelledby="headingThree" data-parent="#accordionExample3">
							    <div class="card-body">
                  <table class="table">
                    <thead>
                      <tr>
                        <th scope="col">CODE</th>
                        <th scope="col">SUBJECT COMBINATION </th>
                        <th scope="col">POSIBLE UNDERGRADUATE COURSES </th>
                      </tr>
                    </thead>
                    <tbody id="tbodyysocial">
                      <tr>
                        <th scope="row">003</th>
                        <td class="colmid"> O/L English and Mathematics </td>
                        <td></td>
                      </tr>
                      <tr>
                        <th scope="row">004</th>
                        <td class="colmid">ACCT, BUS MGT A/L MATHS </td>
                        <td>ACCT, BUS ADIM, PA, BAF, MKT</td>
                      </tr>
                      <tr>
                        <th scope="row">005</th>
                        <td class="colmid"> ACCT, BUS MGT,ECONS </td>
                        <td> ACCT, BUS ADIM, ECONS, PA, BAF, MKT </td>
                      </tr>
                      <tr>
                        <th scope="row">006</th>
                        <td class="colmid"> ACCT, BUS, MGT, GEO </td>
                        <td> ACCT, BUS ADIM, PA, BAF, MKT </td>
                      </tr>
                      <tr>
                        <th scope="row">007</th>
                        <td class="colmid"> ACCT, BUS MGT, GOVT </td>
                        <td> ACCT, BUS MGT, PA, BAF, MKT </td>
                      </tr>
                      <tr>
                        <th scope="row"> 008 </th>
                        <td class="colmid"> ACCT, BUS MGT, SOCIOLOGY </td>
                        <td>  ACCT, BUS MGT, SOCIOLOGY, PA, BAF, MKT </td>
                      </tr>
                      <tr>
                        <th scope="row"> 009 </th>
                        <td class="colmid"> ACCT, ECONS, GEO </td>
                        <td> ACCT, BUS ADMIN, ECONS, PA, BAF, URP </td>
                      </tr>
                      <tr>
                        <th scope="row"> 010 </th>
                        <td class="colmid"> ACCT, ECONS, GOVT </td>
                        <td> ACCT, BUS ADIM, ECONS, BAF, MKT, MC </td>
                      </tr>
                      <tr>
                        <th scope="row"> 011 </th>
                        <td class="colmid"> ACCT, ECONS, SOCIOLOGY </td>
                        <td> ACCT, BUS ADIM, ECONS, SOCIOLOGY, PA, BAF </td>
                      </tr>
                      <tr>
                        <th scope="row"> 012 </th>
                        <td class="colmid"> ACCT, GEO, A/L MATHS </td>
                        <td> 	ACCT, BUS ADIM, ECONS, GEO, PA, BAF, MKT, URP </td>
                      </tr>
                      <tr>
                        <th scope="row"> 013 </th>
                        <td class="colmid"> ACCT,GEO,GOVT	 </td>
                        <td> ACCT, BUS ADIM, ECONS, PA, BAF, MKT </td>
                      </tr>
                      <tr>
                        <th scope="row"> 014 </th>
                        <td class="colmid"> ACCT, GEO, SOCIOLOGY </td>
                        <td> ACCT,BUS ADIM, SOCIOLOGY, MC, PA,BAF,MKT </td>
                      </tr>
                      <tr>
                        <th scope="row"> 015 </th>
                        <td class="colmid"> ACCT, GOVT, A/L MATHS </td>
                        <td> ACCT, BUS ADIM, PA, MKT, BAF </td>
                      </tr>
                      <tr>
                        <th scope="row"> 016 </th>
                        <td class="colmid"> ACCT, GOVT, SOCIOLOGY </td>
                        <td> ACCT, BUS ADIM, SOCIOLOGY, POL SCI </td>
                      </tr>
                      <tr>
                        <th scope="row"> 031 </th>
                        <td class="colmid"> BUS MGT, ECONS, A/L MATHS </td>
                        <td> BUS ADIM, ACCT, ECONS, URP, BAF, MKT </td>
                      </tr>
                      <tr>
                        <th scope="row"> 032 </th>
                        <td class="colmid"> BUS MGT, ECONS, GEO  </td>
                        <td> BUS ADIM, ECONS, ACCT, URP, BAF, MKT </td>
                      </tr>
                      <tr>
                        <th scope="row"> 033 </th>
                        <td class="colmid"> BUS MGT, ECONS, GOVT </td>
                        <td>BUS ADIM,POL SCI, INTER STUDIES, PA, ECONS
                      </td>
                      </tr>
                      <tr>
                        <th scope="row"> 034 </th>
                        <td class="colmid"> BUS MGT, ECONS, SOCIOLOGY </td>
                        <td> BUS ADIM, (SINGLE HONOUR) ACCT, PA, BAF </td>
                      </tr>
                      <tr>
                        <th scope="row"> 035 </th>
                        <td class="colmid"> BUS MGT, GEO, A/L MATHS </td>
                        <td> BUS ADIM, ENVL SCI, ACCT, PA, BAF, MKT </td>
                      </tr>
                      <tr>
                        <th scope="row"> 036 </th>
                        <td class="colmid"> BUS MGT, GEO, GOVT	 </td>
                        <td> PA, BUS ADIM, ACCT, BAF, MKT </td>
                      </tr>
                      <tr>
                        <th scope="row"> 037 </th>
                        <td class="colmid"> BUS MGT, GEO, SOCIOLOGY </td>
                        <td> BUS ADIM, SOCIOLOGY, MKT, ACCT, BAF, PA </td>
                      </tr>
                      <tr>
                        <th scope="row"> 038 </th>
                        <td class="colmid"> BUS MGT, GOVT, SOCIOLOGY </td>
                        <td> BUS ADIM, PA, SOCIOLOGY, MKT, POL SCI, INTER STUDIES, ACCT, BAF </td>
                      </tr>
                      <tr>
                        <th scope="row"> 049 </th>
                        <td class="colmid"> ECONS, GEO, A/L MATHS	 </td>
                        <td> ENVL SCI, URP, (SINGLE HONOUR) ACCT, BAF</td>
                      </tr>
                      <tr>
                        <th scope="row"> 050 </th>
                        <td class="colmid"> ECONS, GEO, GOVT	 </td>
                        <td> URP, ACCT, PA, BAF, MKT, MC, (SINGLE HONOURS)
                      </td>
                      </tr>
                      <tr>
                        <th scope="row"> 051 </th>
                        <td class="colmid"> ECONS, GEO, SOCIOLOGY	 </td>
                        <td> URP(SINGLE HONOURS), in all three subjects) ACCT, PA </td>
                      </tr>
                      <tr>
                        <th scope="row"> 052 </th>
                        <td class="colmid"> ECONS, GOVT, A/L MATHS </td>
                        <td> PA, POL SCI, INTER STUDIES, ECONS, MC, ACCT, BAF </td>
                      </tr>
                      <tr>
                        <th scope="row"> 053 </th>
                        <td class="colmid"> ECONS, GOVT, SOCIOLOGY </td>
                        <td> ECONS, POL SCI, INTER STUDIES, PA, SOCIOLOGY, MC, ACCT, BAF </td>
                      </tr>
                    </tbody>
							      </table>
							    </div>
						    </div>
						  </div>
					  </div>
			    </div> 
        </div>
<!-- section for commercial ends here -->
      </div>
    </div>
  </div>
</div>