<div class="container-fluid col-12" id="banContainerFluid" >
  <div class="container col-12 d-none d-md-block" id="banContainer">
    <div class="banner col-12">
            <img src="images/stu7.png" />
    </div>
  </div>
  <div class="container col-12" id="acceptedContainer">
    <div class="row col-12">
      <h3> IJMB & JUPEB :: Uni Accepted By.</h3>
      <div id="articleDiv" class="col-12">
                    
        <div class="col-xl-3 col-lg-3 col-md-3 col-sm-12 col-xs-12 d-none d-md-block" id="artImg">
          <img src="images/1.jpg" alt="ijmb image">
        </div>
          <div id="artText" class="col-xl-9 col-lg-9 col-md-9 col-sm-12 col-xs-12">
            <p>
              <article>
              IJMB | JUPEB Examinations are highly respected and recognized by various higher institutions in Nigeria. The certificates/results are acceptable in increasing number of institutions in the country. The Federal Government, through its various educational agencies, recognize IJMB | JUPEB as an examining body for both Ordinary and Advanced Level Examinations.
									<br>
								The syllabus is approved by the National Education Research and Development Council (NERDC) and IJMB | JUPEB examination result are listed among the acceptable modes of entry in the JAMB brochure. 
								<!-- For maIJMB | JUPEB results into their undergraduate programmes. -->
									<br>
								This page is intended to list the institutions (specifically, the universities) that presently accepts the IJMB | JUPEB A/Level certificate. This list is not exhaustive, and we hope to keep it updates. In this regard, we encourage you to check your JAMB bronchure for IJMB Acceptability in your school of choice.
              </article>
            </p>
          </div>
          
      <!-- section for art goes here -->
          <div id="accord" class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12">
            <h3> List Of Universities IJMB</h3>

          <div class="row col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12 accordTable">

					<div class="accordion col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12" id="accordionExample">
						<div class="card col-12">
						    <div class="card-header" id="headingOne">
						      <h2 class="mb-0">
						        <button class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
						          List Of Universities That Accept IJMB (Federal, State, Private).
						        </button>
						      </h2>
						    </div>

						    <div id="collapseOne" class="collapse" aria-labelledby="headingOne" data-parent="#accordionExample">
							    <div class="card-body">
                    <table class="table">
                    <thead>
										    <tr>
										      <th scope="col">SN</th>
										      <th scope="col"> UNIVERSITIES </th>
										      <th scope="col"> UNIVERSITIES </th>
										    </tr>
										  </thead>
										  <tbody id="tbodyyijmb">
										    <tr>
										      <th scope="row">1</th>
										      <td class="colmid">Abubakar Tafawa Balewa University, Bauchi</td>
										      <td>Ahmandu Bello University, Zaria</td>
										    </tr>
										    <tr>
										      <th scope="row">2</th>
										      <td class="colmid"> Bayero University, Kano </td>
										      <td>Federal University, Gashau </td>
										    </tr>
										     <tr>
										      <th scope="row">3</th>
										      <td class="colmid"> Federal University Of Petroleum Resources, Effurun </td>
										      <td> Federal University Of Technology, Akure </td>
										    </tr>
										     <tr>
										      <th scope="row">4</th>
										      <td class="colmid"> Federal University Of Technology, Minna </td>
										      <td> Federal University, Duste, Jigwa State </td>
										    </tr>
										     <tr>
										      <th scope="row"> 5 </th>
										      <td class="colmid"> Federal University, Dustin Ma, Kastina </td>
										      <td>  Federal University, Kashere, Gombe State </td>
										    </tr>
										     <tr>
										      <th scope="row"> 6 </th>
										      <td class="colmid"> Federal University , Lafia, Nasarawa State </td>
										      <td> Federal University, Lokoja, Kogi State </td>
										    </tr>
										     <tr>
										      <th scope="row"> 7 </th>
										      <td class="colmid"> Federal University, Otuoke, Bayelsa </td>
										      <td> Federal University, Oye Ekiti, Ekit State </td>
										    </tr>
										     <tr>
										      <th scope="row"> 8 </th>
										      <td class="colmid"> Federal University, Wukari, Taraba State </td>
										      <td> Federal University, Binin Kebbi. </td>
										    </tr>
										     <tr>
										      <th scope="row"> 9 </th>
										      <td class="colmid"> Federal University, Gusua. </td>
										      <td> 	Modibbo Adama University Of Technology, Yola </td>
										    </tr>
										     <tr>
										      <th scope="row"> 10 </th>
										      <td class="colmid"> National Open University Of Nigeria	 </td>
										      <td> Nnamdi Azikwe University, Awka </td>
										    </tr>
										     <tr>
										      <th scope="row"> 11 </th>
										      <td class="colmid"> University Of Abuja, Gwagwalada </td>
										      <td> University Of Agriculture, Abeokuta </td>
										    </tr>
										     <tr>
										      <th scope="row"> 12 </th>
										      <td class="colmid"> University Of Agriculture, Makurdi </td>
										      <td> University Of Benin </td>
										    </tr>
										     <tr>
										      <th scope="row"> 13 </th>
										      <td class="colmid"> University Of Calabar </td>
										      <td> Al Hikmah University, Ilorin </td>
										    </tr>
										     <tr>
										      <th scope="row"> 14 </th>
										      <td class="colmid"> University Of Ibadan </td>
										      <td> University Of Jos </td>
										    </tr>
										    <tr>
										      <th scope="row"> 15 </th>
										      <td class="colmid"> University Of Maiduguri  </td>
										      <td> University Of Uyo </td>
										    </tr>
										    <tr>
										      <th scope="row"> 16 </th>
										      <td class="colmid"> Usmanu Danfodiyo University </td>
										      <td> Salem University, Lokoja </td>
										    </tr>
										    <tr>
										      <th scope="row"> 17 </th>
										      <td class="colmid"> Samuel Adegboyega University, Ogwa </td>
										      <td> Southwestern University, Oku Owa </td>
										    </tr>
										    <tr>
										      <th scope="row"> 18 </th>
										      <td class="colmid"> Tansian University, Umuya </td>
										      <td> University Of Mkar, Mkar </td>
										    </tr>
										    <tr>
										      <th scope="row"> 19 </th>
										      <td class="colmid"> Veritas University	 </td>
										      <td> Wellspring University, Evbuobanosa Edo State </td>
										    </tr>
										    <tr>
										      <th scope="row"> 20 </th>
										      <td class="colmid"> Wesley Univ. Of Science & Tech., Ondo </td>
										      <td> Western Delta University, Oghara </td>
										    </tr>
										    <tr>
										      <th scope="row"> 21 </th>
										      <td class="colmid"> Wukari Jubilee University, Wukari </td>
										      <td> Achievers University, Owo </td>
										    </tr>
										    <tr>
										      <th scope="row"> 22 </th>
										      <td class="colmid"> Adeleke University, Ede </td>
										      <td>Afe Babalola University, Ado Ekiti,Ekiti State </td>
										    </tr>
										    <tr>
										      <th scope="row"> 23 </th>
										      <td class="colmid"> African University Science & Technology, Abuja	 </td>
										      <td> Ajayi Crowther University, Ibadan </td>
										    </tr>
										    <tr>
										      <th scope="row"> 24 </th>
										      <td class="colmid"> Al Hikmah University, Ilorin	 </td>
										      <td> American University Of Nigerian, Yola </td>
										    </tr>
										    <tr>
										      <th scope="row"> 25 </th>
										      <td class="colmid"> Babcock University, Ilishn Remo </td>
										      <td> Baze University </td>
										    </tr>
										    <tr>
										      <th scope="row"> 26 </th>
										      <td class="colmid"> Bells University Of Technolgy, Otta </td>
										      <td> Benson Idahosa University, Benin City </td>
										    </tr>
										     <tr>
										      <th scope="row"> 27 </th>
										      <td class="colmid"> Bingham University, New Karu </td>
										      <td> Bowen University, Iwo </td>
										    </tr>
										    <tr>
										      <th scope="row"> 28 </th>
										      <td class="colmid"> Caleb University, Lagos </td>
										      <td> Caritas University, Enugu </td>
										    </tr>
										    <tr>
										      <th scope="row"> 29 </th>
										      <td class="colmid"> CETEP City University, Lagos </td>
										      <td> Renaissance University, Enugu </td>
										    </tr>
										    <tr>
										      <th scope="row"> 30 </th>
										      <td class="colmid"> Abia State University, Uturu. </td>
										      <td> Adamawa State University, Mubi </td>
										    </tr>
										    <tr>
										      <th scope="row"> 31 </th>
										      <td class="colmid"> Adekunle Ajasin University, Akungba </td>
										      <td> Akwa Ibom State University Of Technology, Uyo </td>
										    </tr>
										    <tr>
										      <th scope="row"> 32 </th>
										      <td class="colmid"> Anambra State University Of Science & Technolgy, Uli </td>
										      <td> Bauchi State University, Gaudau </td>
										    </tr>
										    <tr>
										      <th scope="row"> 33 </th>
										      <td class="colmid"> Benue State University, Makurdi </td>
										      <td> Bakar Abba Ibrahim University, Damaturu </td>
										    </tr>
										    <tr>
										      <th scope="row"> 34 </th>
										      <td class="colmid"> Cross River State University Of Science & Technology, Calabar </td>
										      <td> Delta State University, Abraka </td>
										    </tr>
										    <tr>
										      <th scope="row"> 35 </th>
										      <td class="colmid"> Ebonyi State University, Abakaliki </td>
										      <td> Ekiti State University </td>
										    </tr>
										    <tr>
										      <th scope="row"> 36 </th>
										      <td class="colmid"> Enugu State University Of Science And Technology, Enugu </td>
										      <td> Gombe State University, Gombe </td>
										    </tr>
										    <tr>
										      <th scope="row"> 37 </th>
										      <td class="colmid"> Ibrahim Badamasi Babangida University, Lapia</td>
										      <td> Ignatius Ajuru University Of Education, Rumuolumeni </td>
										    </tr>
										    <tr>
										      <th scope="row"> 38 </th>
										      <td class="colmid"> Imo State University,owerri </td>
										      <td> Kaduna State University, Kaduna </td>
										    </tr>
										    <tr>
										      <th scope="row"> 39 </th>
										      <td class="colmid"> Kano University Of Science & Technology, Wudil </td>
										      <td> Kebbi State University, Kebbi </td>
										    </tr>
										    <tr>
										      <th scope="row"> 40 </th>
										      <td class="colmid"> Kogi Stae University, Anyigba </td>
										      <td> Kwara State University, Ilorin </td>
										    </tr>
										     <tr>
										      <th scope="row"> 40 </th>
										      <td class="colmid"> Ladoke Akintola University Of Technology, Ogbomoso </td>
										      <td> Lagos State University, Ojo, Lagos </td>
										    </tr>
										     <tr>
										      <th scope="row"> 40 </th>
										      <td class="colmid"> Nasarawa State University, Keffi </td>
										      <td> Niger Delta University, Yenagoa </td>
										    </tr>
										     <tr>
										      <th scope="row"> 40 </th>
										      <td class="colmid"> Northwest University, Kano </td>
										      <td> Ondo State University Of Science & Technology, Okitipupa</td>
										    </tr>
										     <tr>
										      <th scope="row"> 40 </th>
										      <td class="colmid"> Osun State Univer, Oshogbo </td>
										      <td> Plateau State University, Bokkos </td>
										    </tr>
										     <tr>
										      <th scope="row"> 40 </th>
										      <td class="colmid"> River State University Of Science & Technology </td>
										      <td> Sokoto State University, Sokoto </td>
										    </tr>
										     <tr>
										      <th scope="row"> 40 </th>
										      <td class="colmid"> Tai Solarin Univ. Of Education, Ijebu Ode </td>
										      <td> Taraba State University, Jalingo </td>
										    </tr>
										     <tr>
										      <th scope="row"> 40 </th>
										      <td class="colmid">Technical University, Ibadan </td>
										      <td> Umaru Musa Yar'Adua University, Kastina </td>
										    </tr>
										     <tr>
										      <th scope="row"> 40 </th>
										      <td class="colmid">Crescent University </td>
										      <td> Elizade University, Ilara Mokin </td>
										    </tr>
										     <tr>
										      <th scope="row"> 40 </th>
										      <td class="colmid"> Evangel University, Akaeze ountain University, Osogbo </td>
										      <td> Godfrey Okoye University, Ugwuomu Nike,Enugu State </td>
										    </tr>
										     <tr>
										      <th scope="row"> 40 </th>
										      <td class="colmid"> Gregory University, Uturu </td>
										      <td> Igbinedion University Okada </td>
										    </tr>
										     <tr>
										      <th scope="row"> 40 </th>
										      <td class="colmid"> Joseph Ayo Babalola University, Ikeji Arakeji </td>
										      <td> Landmark University, Omu Aran </td>
										    </tr>
										     <tr>
										      <th scope="row"> 40 </th>
										      <td class="colmid"> Lead City University, Ibadan </td>
										      <td> Madonna University, Okija </td>
										    </tr>
										     <tr>
										      <th scope="row"> 40 </th>
										      <td class="colmid"> Macpherson University, Seriki Sotaya, Ajebo </td>
										      <td> Nigerian Turkish Nile University, Abuja </td>
										    </tr>
										     <tr>
										      <th scope="row"> 40 </th>
										      <td class="colmid"> Novena University, Ogume </td>
										      <td> Obong University, Ipetumodu, Osun State </td>
										    </tr>
										     <tr>
										      <th scope="row"> 40 </th>
										      <td class="colmid"> Pan African University, Lagos </td>
										      <td> Rhema University, Obeama Asa Rivers State </td>
										    </tr>
										     <tr>
										      <th scope="row"> 40 </th>
										      <td class="colmid"> Crawford University Igbesa </td>
										      <td> Covenant University, Ota </td>
										    </tr>
										     <tr>
										      <th scope="row"> 40 </th>
										      <td class="colmid"> Paul University Awka anambra State </td>
										      <td> Redeemer's Universiy, Mowe </td>
										    </tr>
										  </tbody>
                    </table>	

							    </div>
						    </div>
						  </div>
					  </div>
			    </div> 
        </div>
<!-- section for address ends here -->
        <div id="accord" class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12">
            <h3> List Of Universities JUPEB</h3>
          <div class="row col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12 accordTable">

          <div class="accordion col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12" id="accordionExample">
            <div class="card col-12">
                <div class="card-header" id="headingTwo">
                  <h2 class="mb-0">
                    <button class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="true" aria-controls="collapseTwo">
                      List Of University That Accept JUPEB (Federal, State, Private).
                    </button>
                  </h2>
                </div>

                <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionExample">
                  <div class="card-body">
                    <table class="table">
                    <thead>
										    <tr>
										      <th scope="col">SN</th>
										      <th scope="col"> UNIVERSITIES </th>
										      <th scope="col"> UNIVERSITIES </th>
										    </tr>
										  </thead>
										  <tbody id="tbodyyjupeb">
										    <tr>
										      <th scope="row">1</th>
										      <td class="colmid">Federal University Of Technology, Minna</td>
										      <td>Federal University, Lokoja, Kogi State</td>
										    </tr>
										    <tr>
										      <th scope="row">2</th>
										      <td class="colmid"> Federal University, Otuoke, Bayelsa</td>
										      <td>Federal University, Oye Ekiti, Ekit State</td>
										    </tr>
										     <tr>
										      <th scope="row">3</th>
										      <td class="colmid"> National Open University Of Nigeria </td>
										      <td> Nnamdi Azikwe University, Awka </td>
										    </tr>
										     <tr>
										      <th scope="row">4</th>
										      <td class="colmid"> University Of Agriculture, Abeokuta </td>
										      <td> University Of Agriculture, Makurdi </td>
										    </tr>
										     <tr>
										      <th scope="row"> 5 </th>
										      <td class="colmid"> University Of Benin </td>
										      <td>  University Of Calabar </td>
										    </tr>
										     <tr>
										      <th scope="row"> 6 </th>
										      <td class="colmid"> University Of Ibadan </td>
										      <td> University Of Ilorin </td>
										    </tr>
										     <tr>
										      <th scope="row"> 7 </th>
										      <td class="colmid"> University Of Uyo </td>
										      <td> Usmanu Danfodiyo University </td>
										    </tr>
										     <tr>
										      <th scope="row"> 8 </th>
										      <td class="colmid"> Samuel Adegboyega University, Ogwa </td>
										      <td> Southwestern University, Oku Owa </td>
										    </tr>
										     <tr>
										      <th scope="row"> 9 </th>
										      <td class="colmid"> Veritas University </td>
										      <td> 	Wellspring University, Evbuobanosa Edo State </td>
										    </tr>
										     <tr>
										      <th scope="row"> 10 </th>
										      <td class="colmid"> Wesley Univ. Of Science & Tech., Ondo	 </td>
										      <td> Western Delta University, Oghara </td>
										    </tr>
										     <tr>
										      <th scope="row"> 11 </th>
										      <td class="colmid"> Wukari Jubilee University, Wukari </td>
										      <td> Achievers University, Owo</td>
										    </tr>
										     <tr>
										      <th scope="row"> 12 </th>
										      <td class="colmid"> Adeleke University, Ede </td>
										      <td> Afe Babalola University, Ado Ekiti,Ekiti State </td>
										    </tr>
										     <tr>
										      <th scope="row"> 13 </th>
										      <td class="colmid"> Ajayi Crowther University, Ibadan </td>
										      <td> Al Hikmah University, Ilorin </td>
										    </tr>
										     <tr>
										      <th scope="row"> 14 </th>
										      <td class="colmid"> Babcock University, Ilishn Remo </td>
										      <td> Baze University </td>
										    </tr>
										    <tr>
										      <th scope="row"> 15 </th>
										      <td class="colmid"> Bells University Of Technolgy, Otta  </td>
										      <td> Benson Idahosa University, Benin City </td>
										    </tr>
										    <tr>
										      <th scope="row"> 16 </th>
										      <td class="colmid"> Bingham University, New Karu </td>
										      <td> Bowen University, Iwo </td>
										    </tr>
										    <tr>
										      <th scope="row"> 17 </th>
										      <td class="colmid"> Caleb University, Lagos </td>
										      <td> Caritas University, Enugu </td>
										    </tr>
										    <tr>
										      <th scope="row"> 18 </th>
										      <td class="colmid"> CETEP City University, Lagos </td>
										      <td> Renaissance University, Enugu </td>
										    </tr>
										    <tr>
										      <th scope="row"> 19 </th>
										      <td class="colmid"> Abia State University, Uturu.	 </td>
										      <td> Adekunle Ajasin University, Akungba </td>
										    </tr>
										    <tr>
										      <th scope="row"> 20 </th>
										      <td class="colmid"> Akwa Ibom State University Of Technology, Uyo </td>
										      <td> Anambra State University Of Science & Technolgy, Uli </td>
										    </tr>
										    <tr>
										      <th scope="row"> 21 </th>
										      <td class="colmid"> Abia State University, Uturu. </td>
										      <td>Adekunle Ajasin University, Akungba </td>
										    </tr>
										    <tr>
										      <th scope="row"> 22 </th>
										      <td class="colmid">Akwa Ibom State University Of Technology, Uyo	 </td>
										      <td>Anambra State University Of Science & Technolgy, Uli </td>
										    </tr>
										    <tr>
										      <th scope="row"> 23 </th>
										      <td class="colmid"> Delta State University, Abraka	 </td>
										      <td> Cross River State University Of Science & Technology, Calabar </td>
										    </tr>
										    <tr>
										      <th scope="row"> 24 </th>
										      <td class="colmid"> Benue State University, Makurdi	 </td>
										      <td> Ebonyi State University, Abakaliki </td>
										    </tr>
										    <tr>
										      <th scope="row"> 25 </th>
										      <td class="colmid"> Ekiti State University </td>
										      <td> Enugu State University Of Science And Technology, Enugu </td>
										    </tr>
										    <tr>
										      <th scope="row"> 26 </th>
										      <td class="colmid"> Ignatius Ajuru University Of Education, Rumuolumeni </td>
										      <td> Imo State University,owerri </td>
										    </tr>
										     <tr>
										      <th scope="row"> 27 </th>
										      <td class="colmid"> Kebbi State University, Kebbi </td>
										      <td> Kogi Stae University, Anyigba </td>
										    </tr>
										    <tr>
										      <th scope="row"> 28 </th>
										      <td class="colmid"> Kwara State University, Ilorin </td>
										      <td> Ladoke Akintola University Of Technology, Ogbomoso</td>
										    </tr>
										    <tr>
										      <th scope="row"> 29 </th>
										      <td class="colmid"> Ondo State University Of Science & Technology, Okitipupa </td>
										      <td> Lagos State University, Ojo, Lagos </td>
										    </tr>
										    <tr>
										      <th scope="row"> 30 </th>
										      <td class="colmid"> Osun State University, Oshogbo </td>
										      <td> River State University Of Science & Technology </td>
										    </tr>
										    <tr>
										      <th scope="row"> 31 </th>
										      <td class="colmid"> Tai Solarin Univ. Of Education, Ijebu Ode  </td>
										      <td> Technical University, Ibadan </td>
										    </tr>
										    <tr>
										      <th scope="row"> 32 </th>
										      <td class="colmid"> Crescent University </td>
										      <td> Elizade University, Ilara Mokin </td>
										    </tr>
										    <tr>
										      <th scope="row"> 33 </th>
										      <td class="colmid"> Evangel University, Akaeze ountain University, Osogbo </td>
										      <td> Godfrey Okoye University, Ugwuomu Nike,Enugu State </td>
										    </tr>
										    <tr>
										      <th scope="row"> 34 </th>
										      <td class="colmid"> Gregory University, Uturu </td>
										      <td> University of Lagos </td>
										    </tr>
										    <tr>
										      <th scope="row"> 35 </th>
										      <td class="colmid"> Igbinedion University Okada </td>
										      <td> Landmark University, Omu Aran </td>
										    </tr>
										    <tr>
										      <th scope="row"> 36 </th>
										      <td class="colmid"> Lead City University, Ibadan </td>
										      <td> Madonna University, Okija </td>
										    </tr>
										    <tr>
										      <th scope="row"> 37 </th>
										      <td class="colmid"> Macpherson University, Seriki Sotaya, Ajebo </td>
										      <td> Novena University, Ogume </td>
										    </tr>
										    <tr>
										      <th scope="row"> 38 </th>
										      <td class="colmid"> Obong University, Ipetumodu, Osun State </td>
										      <td> Pan African University, Lagos </td>
										    </tr>
										    <tr>
										      <th scope="row"> 39 </th>
										      <td class="colmid"> Rhema University, Obeama Asa Rivers State </td>
										      <td> Crawford University Igbesa </td>
										    </tr>
										    <tr>
										      <th scope="row"> 40 </th>
										      <td class="colmid"> Covenant University, Ota </td>
										      <td>Paul University Awka anambra State </td>
										    </tr>
										       <tr>
										      <th scope="row"> 40 </th>
										      <td class="colmid"> Redeemer's Universiy, Mowe</td>
										      <td> Joseph Ayo Babalola University, Ikeji Arakeji </td>
										    </tr>
										  </tbody>
                    </table>	

                  </div>
                </div>
              </div>
            </div>
          </div> 
          </div>

      </div>
    </div>
  </div>
</div>