<?php include("includes/header.php"); ?>
  <main>
      <?php include("courses.php"); ?> 
  </main>
<?php include("includes/footer.php"); ?>